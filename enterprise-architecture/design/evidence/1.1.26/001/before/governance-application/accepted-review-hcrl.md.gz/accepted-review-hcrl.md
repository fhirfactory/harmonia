<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

| Decision Review | Subject | Solution Architect Disposition | Comment |
| --- | --- | --- | --- |
| [DR-1](#dr-1) | Backlog Items, delegated lifecycle and acceptance boundaries | Changes Requested | Recorded review directions and two clarifications incorporated; revised candidate awaits acceptance. |
| [DR-2](#dr-2) | Solution-wide software identity and pre-submission verification | Accepted with refinement | Independent X.Y.Z retained; integrated-solution acceptance and required testing made explicit. |
| [DR-3](#dr-3) | Shared evidence, originating items and corrective iterations | Accepted with refinement | Report/HCRL identify items and criteria/conformance/regression/integration evidence; no new ordinary-correction approval. |
| [DR-4](#dr-4) | Supporting governance, Backlog template and bounded tooling | Revise and resubmit | Exact revised diff and minimum Backlog structure submitted in this same iteration. |
| [DR-5](#dr-5) | First accepted software baseline and version | Accepted | Deferred to first appropriately authorised software-development assignment. |
| [DR-6](#dr-6) | Bounded supporting Minutiae and temporal qualification | Accepted with qualification | Original Task time/prefix remain unresolved by explicit disposition; evidence retained. |

# HCRL 1.1.26 / 001 — Software Development Praxis proposal

**PENDING — revised proposal submitted for exact-candidate acceptance.** The
Solution Architect dispositions above are recorded; they do not adopt normative
sources, finalise this HCRL, allocate a release or authorise implementation/Git work.
No iteration advance or independent review cycle has been created.

**Final minor refinement direction:** the Solution Architect confirms substantive
Backlog semantics, development lifecycle, solution-wide verification and release
model are accepted in principle. The latest directions, retained in the same Task,
require only explicit Backlog Item ID/Revision header metadata and correct maintained
README links. The earlier six dispositions/history below are preserved; they are
not reopened as unanswered decisions. Exact corrected candidate acceptance remains
the final review boundary; no adoption or HCRL finalisation is inferred.

**Attributable review:** Mark Hunter, Solution Architect, issued “HCRL 1.1.26/001 —
Solution Architect Review Directions”, followed by clarifications that the existing
Backlog sample does not define future structure/content and specifying minimum
Backlog sections. Exact wording is retained as follow-ups in the
[existing formal Task](../../evidence/1.1.26/001/before/ai-agent-tasks/unresolved-software-development-praxis-proposal.md).
Original and follow-up instruction-entry times are not exposed; no substitute event
is inferred. Original temporal uncertainty receives the explicit DR-6 treatment.

**History and state:** the original [reviewed HCRL](../../evidence/1.1.26/001/before/solution-architect-review/hcrl-1.1.26-001.pending.md.reviewed.gz),
Praxis, assessment, proposed diff, supporting amendments and Task/Report states are
preserved with [source correspondence](../../evidence/1.1.26/001/before/solution-architect-review/source-correspondence.json).
Earlier unrecorded-decision statements describe the initial submission, not the
current dispositions. Preserve the same DR identities and acceptance boundaries.
Branch remains `Mneme-and-Mnemosyne-Build`, HEAD
`441ec989a3853db4ea4dad253e14b8464181f293`; only this proposal/evidence is untracked.
Root Architecture authority remains **1.1.25 / previous 1.1.24**, with
[accepted 1.1.25 qualifications](../../register/1.1.25/hcrl-1.1.25-001.complete.md)
unchanged. The provisional **1.1.25 → 1.1.26** review mapping reserves/allocates
nothing. Recheck the actual predecessor/release plan before later application.

**Revised candidate:** [Software Development Praxis](software-development-praxis.proposed.md),
[Backlog Item template](backlog-item-template.proposed.md),
[backlog README](backlog-readme.proposed.md),
[exact unapplied diff](../../evidence/1.1.26/001/after/governance-amendments.proposed.patch)
and [supporting amendments/tool scope](../../evidence/1.1.26/001/after/supporting-amendments.proposed.md).
The [assessment](../../evidence/1.1.26/001/after/governance-assessment.md) preserves
initial findings with current review correspondence. The
[formal Report](../../evidence/1.1.26/001/after/ai-agent-reports/20261115T233608Z-software-development-praxis-proposal.md)
retains its original production event and records the review correction as an
attributable amendment. New checks are separate from preserved initial evidence in
[correction verification](../../evidence/1.1.26/001/after/review-correction/verification.json).

<a id="dr-1"></a>
## DR-1 — Backlog Items and development lifecycle

**Solution Architect disposition: Changes Requested.** The retained directions
make `docs/backlog/` the single human/agent Backlog location. Items are work-management
artefacts, not Continuum/Motivation elements. They can reference, realise or propose
changes/new architectural elements and capture justified technical work, subject to
established governance, ADD and HCRL. No one-to-one mapping or architectural authority
is conferred. Items specify work; Tasks delegate execution; HCRL records acceptance.

**Clarifications:** the inspected Task 9 sample is not a model for future structure
or content. The minimum is Overview with high-level synopses of Effort, Activities,
Outcome and Acceptance Criteria; Context; Associated Requirements; Expected /
Associated Activity; Expected Outcomes; Acceptance Criteria. The spelling of
“Critera” in the issued list is normalised in the template without changing meaning.

**Correction performed:** Praxis §§3–5 and the new proposed template/README incorporate
that minimum, item scope/constraints, versioned references and many-to-many
Continuum ↔ Backlog → Task → Implementation/Report → HCRL → Accepted Software Release
traceability. Formal Tasks reference item specifications and add execution-specific
instructions rather than duplicate complete specifications. Actual issued wording
is preserved under common provenance. Existing sample bytes are unchanged. Routine
engineering remains delegated; genuine architectural/scope/authority issues escalate.
The revised result is submitted for acceptance, not self-approved.

**Final refinement incorporated:** the item title identifies the item and its header
now explicitly records Backlog Item ID and Backlog Item Revision. The Praxis binds
Task/Report/HCRL references to those values and preserved source content. No identifier
allocation scheme, prescribed revision format or additional minimum section is
introduced. Existing work/architecture/execution/acceptance distinctions are unchanged.

<a id="dr-2"></a>
## DR-2 — Software release identity and verification

**Solution Architect disposition: Accepted with refinement.** Independent repository
software `X.Y.Z` is accepted as a solution-wide identity. Component Maven versions
and build identities are not independently accepted Harmonia baselines. Every software
PR/HCRL submission represents the integrated solution, even for narrow module work.

**Correction performed:** Praxis §§2, 4 and 6 require pre-submission component/unit,
solution-wide regression, solution-wide integration and relevant architecture/
implementation-conformance verification against the exact integrated candidate.
Commands, actual scope, environment, outcomes and material failures are recorded.
Unavailable/unexecuted/failed checks and unresolved dependencies remain explicit;
incomplete required testing needs an exception and explicit Solution Architect
disposition, never an assumed pass. A candidate may expose an exception for
adjudication without claiming its readiness prerequisite is satisfied. No changes
to every module are required. No optional-PR transport choice narrows acceptance.

Immutable identification, exact Git correspondence and independent Architecture
allocation are preserved. Current source-only change policy remains operative until
explicit governance adoption/application. No release is allocated by this correction.

<a id="dr-3"></a>
## DR-3 — Evidence, review and corrective iterations

**Solution Architect disposition: Accepted with refinement.** Existing proposed
Task/Report provenance, autonomy, Implementation Guide conformance, HCRL review,
qualified acceptance, rejection/abandonment, rollback, exact-source correspondence
and closure remain as reviewed.

**Correction performed:** Praxis §§3 and 6–8 explicitly require originating Backlog
Item(s) and revisions in the Implementation Report/HCRL. Evidence maps applicable
item criteria to implementation/results, architectural conformance and solution-wide
regression/integration outcomes; full specifications stay in the items. In-scope
corrections stay in the same increment/proposed release, with appropriate retesting,
superseded-result identification and exact-candidate correspondence. No additional
ordinary-correction approval is introduced. This proposal correction itself remains
in 1.1.26/001 under the existing Task/Report, not a software-development assignment.

<a id="dr-4"></a>
## DR-4 — Supporting governance amendments

**Solution Architect disposition: Revise and resubmit.** The revised prospective diff
now changes seven current governance/instruction/template documents and adds the
Praxis, `docs/backlog/README.md` and `docs/backlog/backlog-item-template.md`.
The [supporting scope](../../evidence/1.1.26/001/after/supporting-amendments.proposed.md)
identifies all ten document paths plus the same bounded existing evidence-helper,
helper-test and tooling-README updates. No new backlog service, catalogue, provenance
record type, approval board, test platform or lifecycle CLI is introduced.

**Performed:** inspected the existing six-line sample and scoped docs instructions;
retained original inputs and follow-ups; revised the proposal/diff and recorded the
six dispositions. Historical backlog and all normative/implementation files remain
unchanged. Existing regression/integration coverage is not inferred from a Maven
phase or the architecture suite; future software assignments identify the actual
solution suites/environments and disclose missing verification.

**Validation:** correction checks cover exact diff applicability/links, minimum
Backlog hierarchy, canonical/review text correspondence, DR/decision preservation,
traceability and verification clauses, prior evidence integrity, event retention
and unchanged source/release/Git state. Actual outcomes and architecture-test results
are retained in correction verification. Earlier evidence remains unchanged and
is not presented as a fresh software-readiness run. Required helper extensions are
still proposed, not installed or claimed operational.

**Final link verification:** the maintained README candidate resolves to
`docs/backlog/backlog-item-template.md` and
`enterprise-architecture/governance/software-development-praxis.md` through its
rebased links, with no proposal-only destinations. The target set/tooling scope
is unchanged. [Pre-refinement correspondence](../../evidence/1.1.26/001/before/final-backlog-refinements/source-correspondence.json)
preserves the prior candidate and [final verification](../../evidence/1.1.26/001/after/final-backlog-refinements/verification.json)
records identity/sections/link/patch/history checks.

**Final bounded results:** PASS for required sections/four synopses, explicit
ID/revision metadata, maintained README destinations, patch consistency/applicability,
prior disposition table and reviewed-input preservation. The mandatory architecture
suite passed 90 tests with zero failures/errors/skips. The evidence checker retains
the previously qualified original Task event as UNRESOLVED; no new material
acceptance concern was identified.

**Remaining review:** final Solution Architect review of this corrected exact
Praxis/template/amendment candidate. Substantive decisions are accepted in principle;
the recorded earlier dispositions remain history and are not reopened. No normative
application or finalisation occurs.

<a id="dr-5"></a>
## DR-5 — Initial software baseline

**Solution Architect disposition: Accepted.** Establish the first accepted software
baseline and initial version only in the first appropriately authorised software
assignment. No retrospective acceptance follows from Git presence. This deferral
is decided, not an outstanding question in this resubmission.

Existing Architecture qualifications retain their actual applicability; they are
not automatic software-test waivers. The Implementation Guide's Draft/Pending
wording and current AGENTS.md compliance obligation remain disclosed and unchanged.
No guide adoption, sample migration or existing software acceptance is manufactured.

<a id="dr-6"></a>
## DR-6 — Minutiae and provenance

**Solution Architect disposition: Accepted with qualification.** Preserve the
original Task's unavailable instruction-entry timestamp and filename prefix as an
explicit provenance exception, retaining existing evidence and all review/acceptance
boundaries. This disposition treats the exception; it does not resolve its factual
UNRESOLVED state or justify inventing a historical event. It is not requested again.

The review directions and subsequent clarifications have separately unavailable
instruction-entry times, disclosed in the same formal Task. No original exception
is claimed to establish those times. The Report's original emission event/filename
are unchanged; a separately captured amendment-production event records this
correction's completed Report amendment. Mechanical checks may still correctly
return UNRESOLVED for the qualified original Task event.

```text
Minutiae-Accepted: Yes
Comment: Solution Architect DR-6, Accepted with qualification; original Task event/prefix remain UNRESOLVED. Retained review directions are the attribution. Later correction evidence records this same activity and does not expand substantive acceptance.
```

Supporting scope remains the formal Task/Report, purpose-selected state/assessment/
verification evidence, links and candidate packaging; substantive meaning stays in
DR-1–DR-5. No architecture acceptance, HCRL completion, release allocation or Git
operation is inferred. The revised exact candidate awaits Solution Architect review.
