<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

| Decision Review | Subject | Solution Architect Disposition | Comment |
| --- | --- | --- | --- |
| [DR-1](#dr-1) | Common Topic definition and runtime identity (R1) | ACCEPTED | The ordered qualified non-versioned path establishes runtime identity. Preserve independent identities and governed reference obligations. |
| [DR-2](#dr-2) | Common TopicMask definition and matching (R2) | ACCEPTED | Accept structural equality, positional and version-aware matching, exact and inclusive containment, and explicit universality. |
| [DR-3](#dr-3) | TopicIdentityStable Feature (E04.01.04.F01) | ACCEPTED | Preserve architectural element identity continuity independently of runtime path identity and retain governed reference-continuity requirements. |
| [DR-4](#dr-4) | IU and Store adapter correspondence and retained qualifications | ACCEPTED WITH QUALIFICATION | Accept the bounded correspondence. Defer IU qualifier vocabulary, specialised mappings and downstream integration to their respective backlog items. |
| [DR-5](#dr-5) | Retained Topic/TopicMask input locator | ACCEPTED | Authorise the exact two-path correction and record it in the Architecture transition that incorporates it. |
| [DR-6](#dr-6) | Architecture transition and standalone Naming prerequisites | ACCEPTED WITH QUALIFICATION | Accept the reconciliation as supporting work for Software 0.1.0. Standalone Naming may start before the Architecture releases when the recorded conditions are met. |
| [DR-7](#dr-7) | Bounded Minutiae | ACCEPTED WITH QUALIFICATION | `Minutiae-Accepted: Yes`. Preserve the unresolved original Task issuance timestamp and filename prefix. |
| [DR-8](#dr-8) | Final.003 replacement ADD and retirement of superseded text | PENDING EXACT CANDIDATE REVIEW | Final.003 design and incorporation direction are accepted. Review the exact seven-element replacement and two association descriptions. |
| [DR-9](#dr-9) | Pre-1.0.0 Software Development Praxis amendment | PENDING EXACT AMENDMENT AND SCOPE REVIEW | The principle is accepted. Review its expression in the common Praxis and authorise its incorporation scope. |
| [DR-10](#dr-10) | Final.003 transition sequence and verification | PENDING DISPOSITION | Confirm the predecessor, DR-5 application placement, verification treatment and authorised release scope. |

# HCRL 1.1.28 / 001 — Topic and TopicMask Continuum reconciliation

**Status** · Pending Solution Architect review of the exact Final.003 incorporation
candidate. The original seven dispositions are retained. DR-8–DR-10 record the
additional decisions needed for the replacement. Architecture 1.1.26 remains
the current incorporated release.

**Disposition correspondence** · The [Solution Architect’s supplied dispositions][dispositions]
govern DR-1–DR-5 and DR-7. The [revised instruction][dr6-task] governs DR-6.
The [disposition completion report][disposition-report] verifies the recorded result.
[Final.003][final-003] was accepted under the [design disposition][final-003-acceptance].
The [current Task][final-003-task] records the subsequent approval of the
incorporation direction and the pre-1.0.0 principle.

**Origin** · Accepted Architecture 1.1.26, Git `f1d3c4a896731e05c40b1f21e4bf1b96bdcf3adb`,
tree `1846199b36bbfb07c87746c1367c059698b7120d`, branch
`feature/BL-0003-Calliope-Topic-and-TopicMask`. Software development target
`0.1.0-SNAPSHOT`. The [foundation reset][reset] superseded exploratory software
candidates and preserved the qualified accepted design.

**Proposed target** · 1.1.28, conditional on [1.1.27/002][archunit] closing first
as a separate Architecture transition. DR-6 sets the conditions under which
standalone Naming can begin ahead of those releases. The current accepted
Architecture release remains 1.1.26.

**Original review basis · DR-1–DR-7** · The [issued Task][task], qualified accepted
[Final.001.001][design], [Software HCRL 004 DR-10][design-acceptance],
[007 finalisation provenance][finalisation] and [1.1.25 DR-3][predecessor-topic].
The [locator patch][locator] and [original Naming ADD][candidate] retain their
reviewed correspondence in that order against the origin. The original
DR-1–DR-7 wording and original verification describe that review.

**Current review basis · DR-8–DR-10** · Review the exact [replacement ADD][final-003-add]
after the [locator repair][locator] in isolation, and the [Praxis amendment][coherence-praxis]
as a separately adjudicable part of the proposed change set. Use the [incorporation
Report][final-003-report] for candidate correspondence and check outcomes.
The [HCRL preimage][hcrl-preimage] preserves the exact pending record before this
update. Earlier proposals and reviews remain evidence of their respective states.

<a id="dr-1"></a>
## DR-1 — Common Topic definition and runtime identity (R1)

The 1.1.25 incorporated runtime UUID and mandatory sequence-number representation
conflict with the qualified accepted ordered path. Adopt the non-versioned ordered
qualifier/value path for identity, equality, hashing and ordering. Optional entry
versions carry independent meaning. The amendments cover immutable entries and
construction, literal ancestry, derived naming forms, strict escaping and parsing,
and ordered logical reconstruction. Explicit positions support construction and
carry no independent identity or required field in interchange. The runtime model
permits distinct qualified paths with the same unqualified name. Existing governed
registry-scope uniqueness rules, aliases and reference obligations remain in force
at their respective boundaries. The Topic DataObject and its representation retain
their existing identifiers. [Naming ADD patch][candidate] · [Final.001.001 §§1–3][design]

**Solution Architect disposition · ACCEPTED.** Accept the proposed common Topic
definition and its correspondence to the qualified Naming design. The ordered,
qualified, non-versioned path establishes runtime Topic identity. Preserve
the independent identities and obligations of architectural elements, InformationUnits
and governed references. Incorporation addresses R1's common-model contradiction.
Applicable reference or registry migration and changes to the uniqueness scope
require separate treatment. Registry service design and Topic instance allocation
remain outside this correspondence.

<a id="dr-2"></a>
## DR-2 — Common TopicMask definition and matching (R2)

Adopt the ordinary mask's structural equality over ordered qualifier/value and
optional version expressions and its containment flag. Retain exact-depth default,
trailing inclusive containment, full-field positional RE2/J evaluation and the
distinction between absent, present-empty and other version criteria. Explicit
universal masks have their own logical kind. The amendment covers builder
validation, escaped ordinary expressions, logical interchange, bounded evaluation
and fail-closed semantics. The TopicMask-to-Topic association describes the same
neutral selection responsibility. Update its description while retaining its native
type, identifier, direction, endpoints and original evidence. [Naming ADD patch][candidate] · [Final.001.001 §§4–7][design]

**Solution Architect disposition · ACCEPTED.** Accept the proposed TopicMask
definition and matching semantics. Preserve structural equality, positional matching,
optional version constraints, exact and inclusive containment, and explicit universal
matching. Exclude obsolete runtime UUID identity and historical exploratory
compatibility semantics. Incorporation addresses R2's common-model contradiction.
Existing governed selectors, where present, retain the requirement for exact or
inclusive criterion equivalence, established unrestricted intent, and evidence
against wider selection when migrated. Themis and the consuming Features retain
their decisions.

<a id="dr-3"></a>
## DR-3 — TopicIdentityStable Feature (E04.01.04.F01)

The accepted Feature says Topic identities survive rename and reclassification.
Its unqualified wording conflicts with Final.001.001 when applied to a changed
runtime Topic path. The [previous DR-3][prior-identity] records deferral of that
tension for a different assignment. The amendment preserves the Feature identity,
and scopes rename continuity to a governed architectural element that remains the
same. A changed qualified runtime path establishes a different runtime identity.
Existing governed historical references retain their explicit continuity treatment.
[TopicIdentityStable preimage][identity-feature] · [Naming ADD patch][candidate]

**Solution Architect disposition · ACCEPTED.** Accept the proposed clarification
of TopicIdentityStable. Architectural element identity continuity is independent
of runtime Topic identity. Changing a runtime Topic's qualified path establishes
a different runtime Topic identity. Preserve applicable governed reference-continuity
requirements.

<a id="dr-4"></a>
## DR-4 — IU and Store adapter correspondence and retained qualifications

The logical and conceptual IU definitions separately assert a Topic UUID. Update
both descriptions and the existing IU-to-Topic association to distinguish the
persistent IU UUID from its Topic's established unqualified designation and the
Topic's own qualified runtime identity. The exact qualified IU vocabulary and
boundary mappings remain deferred under R3. The Store adapter description refers
to dot-separated text evaluation. Point it to shared TopicMask evaluation over
structured Topics. Its capability registration, full-coverage and instance
selection obligations retain their existing scope. All other graph assertions and
ownership arrangements remain as recorded. [Naming ADD patch][candidate]

**Solution Architect disposition · ACCEPTED WITH QUALIFICATION.** Accept the
narrow IU and Store adapter correspondence changes. Preserve IU identity independence
and shared TopicMask selection semantics. Defer precise IU qualifier vocabularies,
specialised reference mappings and downstream integration decisions to their
appropriate backlog items. Functional service implementation and redesign remain
outside this reconciliation.

Preserve the other DR-10 qualifications. R4's identity-domain distinction is
represented here. The Foundation Reset removed the exploratory implementation's
compatibility obligations. Applicable governed persisted data, registry and alias
contracts remain subject to preservation or adjudicated migration. R5 keeps module
allocation, pinned RE2/J, release limits and the separate `themis-api` concern in
their governed scope. R6 keeps logging integration, bounded latency, reliability
and uncertain delivery open. Naming implementation, its behavioural evidence and
the other model increments require their own assignments. [Software DR-10 qualifications][design-acceptance] · [Software HCRL 009 DR-3][reset]

<a id="dr-5"></a>
## DR-5 — Retained Topic/TopicMask input locator

The live validator fails at the already missing `retainedAt` path ending in
`accepted-input/DRP-Topic-and-TopicMask.Final.001.000.md`. Both common elements
pin SHA-256 `1690ca87200db65d2254acfb5af68b7b960fb044934682b6ed89eb77ce9c5e40`.
The retained file with basename `DRP-Topic-and-TopicMask.Final.001.md` matches
that digest and the historical input inventory. The current source with suffix
`.001.000.md` is byte-identical and has its own separate source locator. The
correction changes the two `retainedAt` values only. It preserves the source
locators, selectors, digest, authority, retained bytes and historical records.
Canonical validation passes with the locator-only patch in isolation.
[Retained input][retained] · [Locator patch][locator] · [Prior reset qualification][reset-verification]

**Solution Architect disposition · ACCEPTED.** Authorise the precise two-path
locator correction. Preserve the verified digest, source evidence, historical
provenance and original architectural authority. Record the correction in the
Architecture transition that incorporates it. Preserve 1.1.27/002's existing
review and evidence.

**Final.003 candidate replay** · The accepted patch reproduces the locator-only
pass on the exact 1.1.26 source and supplies the replacement ADD's preimage.
The repair is still absent from the live Continuum. DR-10 retains the decision
on its application placement. [Current verification][final-003-report]

<a id="dr-6"></a>
## DR-6 — Architecture transition and standalone Naming prerequisites

**Solution Architect disposition · ACCEPTED WITH QUALIFICATION.** The Topic and
TopicMask Continuum reconciliation is accepted as supporting architectural work
for Software 0.1.0. Architecture 1.1.26 remains the accepted baseline. Preserve
the separately governed 1.1.27/002 amendment and the proposed 1.1.28/001
reconciliation. Incorporate architectural changes through the established
Architecture Change Review and release process. Architecture release identities
and Software 0.1.0 retain their independent standing. [Revised disposition][dr6-task]

**Standalone Naming implementation** may begin before completion and publication
of Architecture 1.1.27 and 1.1.28 when all five conditions are met.

1. The accepted Naming design establishes an unambiguous implementation contract.
2. The Solution Architect has accepted Backlog Item 0003.
3. Applicable implementation prerequisites and outstanding decisions have explicit dispositions.
4. Architectural discrepancies remain recorded and governed.
5. Software acceptance claims architectural conformance only to the extent the evidence establishes it.

The architectural reconciliation must be incorporated and verified before any
dependent acceptance requiring it. A bounded implementation assignment follows
the [Software Development Praxis][software-praxis].

The complete isolated candidate passes canonical validation for 6,563 elements
and 9,427 relationships. It preserves every canonical and Exchange identifier,
graph endpoint, navigation entry and all 1,304 authored Views. The candidate
Exchange passes offline XSD and reference checks and regenerates byte-identically.
Published model, reader and narrative material remains at 1.1.25 under the accepted
governance-only 1.1.26 transition. After authorised incorporation, regenerate the
root Manifest, Exchange, reader and narrative through the existing tools at the
authorised version. [Verification][verification] · [Architecture 1.1.26 publication scope][predecessor] · [Release policy][policy]

**Original candidate's remaining Architecture review and verification** · Before closing a dependent
transition, establish which authorised scope carries DR-5 or record the specific
verification treatment. Recheck the exact accepted predecessor and rerun applicable
checks before application. The current ArchUnit command executes zero tests on the
reset checkpoint. Its missing coverage remains open for explicit disposition or
treatment through the separately governed 1.1.27/002 amendment. The canonical
validation result establishes only its recorded scope. DR-10 records the corresponding
open decisions for the Final.003 candidate. [Disposition update report][dr6-report]

<a id="dr-7"></a>
## DR-7 — Bounded Minutiae

**Solution Architect disposition · ACCEPTED WITH QUALIFICATION.** The bounded
group comprises the [Task Detail][task], the [reconciliation Report][report],
and the supporting patch and verification evidence. The original Task issuance
timestamp and filename prefix remain **UNRESOLVED** under the recorded qualification.

```text
Minutiae-Accepted: Yes
Comment: The available Task, Report and verification provenance is accepted for this bounded reconciliation. The original Task issuance timestamp and filename prefix remain unresolved. Do not invent or reconstruct historical timestamps or identifiers.
```

<a id="dr-8"></a>
## DR-8 — Final.003 replacement ADD and retirement of superseded text

Use [Final.003][final-003] as the accepted R1/R2 design. Refine the existing Topic,
TopicMask, Calliope-Models, logical InformationUnit, conceptual Information Unit,
TopicIdentityStable Feature and Mnemosyne Adapter (Store) definitions in place.
Keep the common Topic's ordered qualified, version-independent runtime identity,
opaque optional versions, immutable construction and strict reconstruction. Adopt
explicit mask kinds, positional wildcard and version criteria, bounded numeric
comparisons and endpoint validation, strict interchange and safe failure outcomes.
Carry the supported Java surface, package containment and invocation-local
diagnostic boundary into the existing Calliope responsibility. The current design
requires pre-1.0.0 consumer coherence and supplies no superseded selector service.

The two association descriptions refine the existing TopicMask-to-Topic and
logical IU-to-Topic correspondence. The candidate preserves all element and
relationship identities, endpoints, directions, interfaces, dependency edges and
Views. The IU UUID remains an independent identity. The governed registry,
authority, IU vocabulary and specialised mappings retain their independently
established scope. Coherent refactoring applies to affected consumers at their
own interfaces. [Replacement ADD][final-003-add] · [Final.003 §7][final-003-boundaries]

The exact candidate replaces both earlier ADDs in the proposed application
sequence. It removes the temporary `namingReconciliation` marker and represents
design-source authority using existing scoped bindings and provenance. Retire the
eight identified passages from the affected current definitions. The live
committed preimages remain retrievable from Git. The current authoritative
replacement retains the applicable obligations, including the active IU
guardrails and established 1.1.25 IU and Store dispositions. The earlier
RE2/J obligations in DR-2 and DR-4 remain part of the original review history.
[Retired-source correspondence][retirements] · [Earlier Final.003 proposal][earlier-final-003-add]

The exact isolated candidate passed canonical and Exchange checks. Its
replacement semantics and bounded retirement remain for Solution Architect
review before application. [Validation evidence][final-003-report]

**Solution Architect disposition · PENDING.** Review the exact replacement ADD
and retirement, including the proposal to supersede the earlier ADDs for this
transition and preserve their original dispositions as decision history.

<a id="dr-9"></a>
## DR-9 — Pre-1.0.0 Software Development Praxis amendment

The accepted pre-1.0.0 principle requires one coherent implementation of the
current accepted architecture. Dependency analysis establishes all affected
components and consumers. Update their contracts, interfaces, adapters,
representations, configuration, integrations, tests, fixtures, documentation and
build dependencies as applicable. Completion requires applicable regression and
integration verification of the reconciled system. Superseded pre-1.0.0 APIs and
implementations carry no backward-compatibility obligation.

The exact [Praxis amendment][coherence-praxis] adds this principle to §2,
requires scoped dependency analysis and verification in the Backlog Item under
§3, and records conformance and actual results with the existing Implementation
Report and software HCRL under §6. This is a normative governance amendment to
the current [Software Development Praxis][software-praxis]. The exact patch
applied unchanged in the isolated candidate. The live Praxis retains its present
authority and bytes. [Current Task][final-003-task] · [Validation evidence][final-003-report]

**Solution Architect disposition · PENDING.** Review the exact amendment. The
recommended scope is a separately recorded governance decision in the same
incorporation change set as DR-8, if authorised. If the scope is to proceed
separately, identify its own governed transition.

<a id="dr-10"></a>
## DR-10 — Final.003 transition sequence and verification

Preserve [1.1.27/002][archunit] as a separate Architecture review. The candidate
was validated against the current accepted 1.1.26 source with DR-5 applied in
isolation. A resulting 1.1.28 remains conditional on a reviewed and accepted
1.1.27 predecessor. Confirm which transition carries DR-5 before any dependent
gate closes. If it is carried by 1.1.27, verify the exact correction there and
replay the authorised remainder against that predecessor. If assigned to the
Final.003 transition, disposition any earlier gate that depends on the correction.
Each accepted change set receives its applicable increment once.
[Release policy][policy] · [Review Praxis][review-praxis]

The live validator reproduced the pre-existing locator **FAIL**. DR-5 alone and
the combined candidate passed. The combined result preserves 6,563 elements,
9,427 relationships and 1,304 authored Views and produces deterministic,
schema-valid Exchange XML. The named ArchUnit source suite remains unavailable.
Actual Archi transport and human review remain outstanding. The evidence layout
check retains four historical unresolved Task event times/prefixes. Apply the
existing DR-7 qualification only to its recorded group and establish explicit
treatment for the other outstanding provenance and verification matters. Candidate
checks establish neither application nor release closure.
[Validation evidence and exceptions][final-003-report]

**Solution Architect disposition · PENDING.** Confirm the exact predecessor,
DR-5 carrier, joint or separate Praxis scope and applicable verification
treatment. Review the actual incorporated result before release completion.

**Software follow-on** · Revise [Backlog Item 0003][backlog-0003] separately
against Final.003, including affected dependency refactoring and conformance
criteria. Preserve the exact [Software 010 candidate and review][software-010].
Carry strict XML reconstruction and encoding, early depth, accurate failure
metadata, public-surface and package containment, test accounting, documentation
and applicable integrated verification into successor review. The older
RE2/J-specific findings retain their evidence role for the original candidate.
The next standalone assignment requires an accepted backlog revision and the
other DR-6 prerequisites. Dependent acceptance requires incorporated and verified
architecture. [Independent software review][independent-010]

[task]: ../../evidence/1.1.28/001/before/ai-agent-tasks/unresolved-topic-topicmask-continuum-reconciliation.md
[dispositions]: ../../evidence/1.1.28/001/before/ai-agent-tasks/unresolved-complete-disposition-record.md
[disposition-report]: ../../evidence/1.1.28/001/after/ai-agent-reports/20261124T062555Z-complete-disposition-record.md
[dr6-task]: ../../evidence/1.1.28/001/before/ai-agent-tasks/unresolved-revised-dr-6-disposition.md
[dr6-report]: ../../evidence/1.1.28/001/after/ai-agent-reports/20261124T055110Z-revised-dr-6-disposition.md
[report]: ../../evidence/1.1.28/001/after/ai-agent-reports/20261124T054105Z-topic-topicmask-continuum-reconciliation.md
[verification]: ../../evidence/1.1.28/001/after/verification.json
[locator]: ../../evidence/1.1.28/001/after/01-retained-topic-input-locator.patch
[candidate]: ../../evidence/1.1.28/001/after/02-topic-topicmask-continuum.patch
[design]: ../../offline-design/DRP-Topic-and-TopicMask.Final.001.001.md
[design-acceptance]: ../software-0.1.0/hcrl-software-0.1.0-004.pending.md#dr-10
[finalisation]: ../software-0.1.0/hcrl-software-0.1.0-007.pending.md#dr-1
[reset]: ../../register/software-0.1.0/hcrl-software-0.1.0-009.complete.md#dr-3
[reset-verification]: ../../register/software-0.1.0/hcrl-software-0.1.0-009.complete.md#dr-2
[predecessor]: ../../register/1.1.26/hcrl-1.1.26-001.complete.md
[predecessor-topic]: ../../register/1.1.25/hcrl-1.1.25-001.complete.md#dr-3
[prior-identity]: ../1.1.27/hcrl-1.1.27-001.pending.md#dr-3
[archunit]: ../1.1.27/hcrl-1.1.27-002.pending.md
[retained]: ../../evidence/1.1.25/001/before/accepted-input/DRP-Topic-and-TopicMask.Final.001.md
[identity-feature]: ../../../continuum/strategy/capability/feature/9210349f026b4ff1aca1092c309b4139.md
[policy]: ../../../governance/architecture-release-policy.md
[software-praxis]: ../../../governance/software-development-praxis.md
[final-003]: ../../offline-design/DRP-Topic-and-TopicMask.Final.003.md
[final-003-boundaries]: ../../offline-design/DRP-Topic-and-TopicMask.Final.003.md#7-consumer-boundaries
[final-003-acceptance]: ../../evidence/1.1.28/001/before/ai-agent-tasks/20261124T222614Z-topic-drp-final-003-acceptance.md
[final-003-task]: ../../evidence/1.1.28/001/before/ai-agent-tasks/20261124T234229Z-final-003-incorporation-review.md
[final-003-report]: ../../evidence/1.1.28/001/after/ai-agent-reports/20261124T235126Z-final-003-incorporation-review.md
[final-003-add]: ../../evidence/1.1.28/001/after/final-003-incorporation.proposed.patch
[earlier-final-003-add]: ../../evidence/1.1.28/001/after/final-003-continuum-add.proposed.patch
[retirements]: ../../evidence/1.1.28/001/after/final-003-retired-source-record.md
[coherence-praxis]: ../../evidence/1.1.28/001/after/software-development-praxis-pre-1-0-0.proposed.patch
[hcrl-preimage]: ../../evidence/1.1.28/001/before/review-disposition/hcrl.before-final-003-incorporation.md.gz
[review-praxis]: ../../../governance/architecture-review-praxis.md
[backlog-0003]: ../../../../docs/backlog/BacklogItem-0003-Calliope-Topic-and-TopicMask.v000.003.md
[software-010]: ../software-0.1.0/hcrl-software-0.1.0-010.pending.md
[independent-010]: ../../evidence/software-0.1.0/010/after/ai-agent-reports/20261124T091229Z-naming-0003-independent-review.md
