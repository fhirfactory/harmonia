<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

# Harmonia Architecture Modelling Strategy

## Authority and semantic compatibility

**Accepted Solution Architect decision — 2026-10-19, governance release 1.0.14.**
The [Architectural Axioms](architectural-axioms.md) remain controlling. AX-04
separates architectural semantics from machinery; AX-14 preserves meaningful
distinctions; AX-17 preserves architectural authority and explicit uncertainty.
This decision is consistent with those axioms: it makes an existing kind of
architectural assertion explicit without deriving authority from a tool.

Harmonia deliberately constrains the flexibility available in ArchiMate so that
architectural meaning remains consistent and machine-processable. A Harmonia
specialisation of an ArchiMate element or relationship SHALL remain semantically
compatible with its underlying native ArchiMate concept. Specialisation MAY
narrow or qualify native meaning; it SHALL NOT contradict or repurpose it.
Native concepts retain their native semantics. Where a Harmonia definition has
no faithful native representation, its representation requires an explicit
modelling decision rather than a reinterpretation of a native concept.

## Explicit architectural Home

Harmonia SHALL use a **directed ArchiMate Association specialised as `Home`** to
explicitly identify the logical architectural home of an element where that
home cannot be faithfully represented by a native ArchiMate structural
relationship. The direction is:

```text
element -- directed Association «Home» --> architectural home
```

For example, the Solution Architect explicitly authored:

```text
[Business Process] Identifier Verification
    -- directed Association «Home» --> [Feature] Identifier Capture
```

Association supplies an associated relationship between the endpoints; `Home`
qualifies that association with the Harmonia logical-belonging predicate. It
does not make Association a structural relationship. `Home` is the **Archi
relationship specialisation**, not an arbitrary relationship Name. A relationship
Name SHOULD remain absent unless it has a separately meaningful architectural
purpose.

Home SHALL NOT mean Composition or structural containment, Realization, Serving,
ownership or governance authority, or dependency. It SHALL NOT be inferred as a
consequence of any of them. Home is an additional, orthogonal architectural
assertion; it replaces no valid native semantic relationship.

### Independence from Realization and presentation

Realization retains its native ArchiMate semantics: it states what architectural
element or elements the source realises. An element may realise several
Features. Native Realization SHALL NOT, by itself, establish **Home, logical
containment, parentage, ownership, naming context or navigation context**.
An explicit Home and a Realization between the same endpoints assert different
things and may coexist.

Folder/model-tree placement and View placement are not substitutes for an
explicit Home. Realization, Serving, Flow, Composition, folders, Views, names,
graphical proximity and other contextual heuristics SHALL NOT generate Home.
Having only one Realization does not establish Home. Prospective Home assertions
SHALL be explicitly authored and reviewed under the
[Change Review contract](archimate-ingestion-change-review.md).

### Interchange evidence

The Solution Architect's current
[1.0.8 submission](../../archimate/exchange/ingest/1.0.8/HarmoniaArchitecture-1.0.8.xml)
contains four actual authored examples, independently of the earlier experiment.
Open Exchange preserves native `Association`, source, target, direction through
`isDirected="true"`, and the Archi specialisation through the relationship
property `specialization = Home`. In this export the property's definition ID
is `specialization` and its displayed definition name is `Specialization`.
Property-definition references must be resolved rather than treated as a
universal fixed identifier. This is empirical interchange evidence, **not the
architecture definition of Home**. Other serializations must preserve the same
architectural assertion.

## One-time Business baseline normalisation

This accepted task authorises a one-time materialisation of deterministically
established logical Feature homes for **existing governed** Business Functions,
Business Processes and Business Services. It authorises no new architectural
meaning and no additional Home for new 1.0.8 elements inferred from Realization.
The Solution Architect's four authored relationships remain unchanged.

The [fixed Business Home register](baseline/business-homes.json) records every
existing Business behaviour assessment, exact governed identities, source
statements, standing, and unresolved or competing candidate contexts. Its
accepted rows use explicit Business catalogue **Functions & Exposed Services /
Feature responsibility allocations**, corroborated by the reconciled baseline's
exact source keys and Feature bindings. A Process requires its own explicit
`Governed Process` allocation in that responsibility statement; it does not
inherit Home through a Function. A sole Realization, association edge, name,
heading or navigation path supplies no migration authority. Conflicting or
incomplete evidence remains for Solution Architect adjudication. Proposed
Feature ancestry or other retained standing is not promoted by normalisation.

This register is the accepted migration result, not a prospective inference
rule. Publication replays only its literal accepted relationships; it does not
discover additional homes from changed catalogues or relationships. New or
changed Home requires an explicitly reviewed assertion. The original capture,
all native relationships, and historical publications remain preserved.

## Deliberately deferred decisions

This decision establishes no general mandatory cardinality or requirement that
every applicable element have a Home; no exhaustive source/target type lists;
no Home inheritance; no automatic naming, folder or View consequences; and no
Information Architecture or Application Architecture Home rules. The current
Business examples target Features, native `Capability`; they do not establish
an exhaustive target restriction. General rules require a separate Solution
Architect decision. The existing CT3 → Feature Composition rule remains distinct.
