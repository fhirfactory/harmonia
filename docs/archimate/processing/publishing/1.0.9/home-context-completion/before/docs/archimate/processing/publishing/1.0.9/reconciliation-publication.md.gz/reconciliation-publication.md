<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

# RAD-1.0.9 — authorised 1.0.8 reconciliation publication

All 26 accepted run-001 CRs and all six accepted run-002 CRs are reconciled.
Run-001: CR-001–015, CR-022/024/026/028 and CR-030–036. Run-002: CR-001–006.
**Accepted CRs not reconciled: none.** Per-CR results, required resulting states
and actual published-state signatures are recorded in
[run-001 execution results](../../ingestion/1.0.8/run-001/reconciliation/execution-001/results.json)
and [run-002 execution results](../../ingestion/1.0.8/run-002/reconciliation/execution-001/results.json).
The ten interpretation findings retain their historical On-Hold Dispositions and
Resolved Outcomes. The original inputs, detection, prior review revisions and
pre-execution adjudicated reviews remain preserved in the ingestion runs.
Execution revisions 5 and 2 link the later architect decisions and actual results
without rewriting earlier instructions. The preservation check covers 108 original
files and proves the ten complete interpretation records remain byte-identical.

The resulting model contains 1,308 elements, 1,077 relationships and 1,198 Views.
It retains all 1,299 existing identities and adds nine UUIDv4 identities, persisted
once in the governed accepted-ingestion source capture. Publication allocates none.
Six accepted CT3 → Feature Compositions retain native Composition; four native
Realizations coexist with four directed Associations specialised as Home.
The 208 fixed baseline Home assertions remain unchanged. The 93 unestablished and
18 ambiguous baseline Home assessments remain unresolved and non-blocking.

Only the four accepted authored Views change. Their exact submitted type,
membership, connection references, geometry and styles are preserved. Other Views,
existing elements and existing relationships retain their prior semantic content.
Existing baseline Name/displayName conformance debt is preserved outside these CRs;
every new element's native Name equals its derived displayName.

The Product naming execution stop was resolved by the Solution Architect's
2026-10-19 vocabulary decision: native Product uses `PRODUCT`. The four Product
names below are derived by the shared lexical and qualification machinery.
No Product-specific naming algorithm or inferred hierarchy is introduced.
This was the sole execution-contract gap requiring a new architect decision;
it is resolved. The [execution-contract observation](../../ingestion/1.0.8/run-001/reconciliation/execution-001/execution-contract.md)
preserves the stop, decision, resumption and harness observations. No further
architectural/governance gap or matter requiring new Solution Architect adjudication
was identified. The outstanding Home cases remain modelling/adjudication debt.

| run-001 CR | displayName | canonicalId | canonicalName |
| --- | --- | --- | --- |
| CR-001 | [Feature] Identifier Capture | 3cae3c4810974c5f8ee5a4c942f38b07 | CT1-BEC-EntityInformationEnablement.CT2-BEC-ClientAdministration.CT3-BEC-PersonIdentityAdministration.FEAT-IdentifierCapture |
| CR-002 | [Product] Provider Registry - Satellite | 1846c512d8f5405aaa4f4e33b5177098 | PRODUCT-ProviderRegistrySatellite |
| CR-003 | [Product] Provider Registry - Central | 407f93e81fd740e6b10728941a5a5172 | PRODUCT-ProviderRegistryCentral |
| CR-004 | [Product] Practitioner Collaboration Service | 09a928910d3d458da3aebfb93d114654 | PRODUCT-PractitionerCollaborationService |
| CR-005 | [Product] Health Information Exchange Service | 59fb1f7c79eb4e5387fb0652649c2b9c | PRODUCT-HealthInformationExchangeService |
| CR-006 | [Business Service] Identifier Create | 063b7a6b4ad549428a7566a4ce2c5de5 | SV-IdentifierCreate |
| CR-007 | [Business Service] Identifier Update | 281155a0820942b884a13fa08d2e0b04 | SV-IdentifierUpdate |
| CR-008 | [Business Process] Identifier Verification | 6ea7f8afe17d4319ab6fa9691db4328d | PR-IdentifierVerification |
| CR-009 | [Business Service] Verify Identity Source | b95f652107f4420b86cc10fb893c9b01 | SV-VerifyIdentitySource |

Governed Markdown RAD changes are the accepted element entries in
[Features](../../../../markdown/governance/baseline/features.md),
[Services](../../../../markdown/governance/baseline/services.md),
[Processes](../../../../markdown/governance/baseline/processes.md), the new
[Products catalogue](../../../../markdown/governance/baseline/products.md), and the
[17 accepted relationship records](../../../../markdown/governance/baseline/relationships.md#accepted-108-instance-relationships).
The source capture, correspondence manifest and baseline README connect these
derived catalogues to the accepted CRs. The naming contract records `PRODUCT`;
the release policy records the expressly authorised RAD number. No additional
architectural responsibility or hierarchy is introduced.

Validation passed 177 ArchiMate tests,
72 governance tests and
90 Java architecture tests. Publication
checks include identity, relationship types/directions, semantic endpoints,
View references/geometry, offline Open Exchange schema validation and preservation.

| Check | Result | Evidence |
| --- | --- | --- |
| archi_transport | PASS | `docs/archimate/processing/publishing/1.0.9/roundtrip/archi-transport-verification.json` |
| archi_transport_probe | PASS | `docs/archimate/processing/publishing/1.0.9/validation/archi-transport-probe.log.gz` |
| archimate_tests | PASS | `docs/archimate/processing/publishing/1.0.9/validation/rad109-archimate-tests-final.log.gz` |
| architecture_tests | PASS | `docs/archimate/processing/publishing/1.0.9/validation/architecture-tests-java21.log.gz` |
| governance_tests | PASS | `docs/archimate/processing/publishing/1.0.9/validation/rad109-governance-tests.log.gz` |
| identity | PASS | `docs/archimate/processing/publishing/1.0.9/validation/rad109-identity.log.gz` |
| identity_registry | PASS | `docs/archimate/processing/publishing/1.0.9/validation/rad109-identity-registry.log.gz` |
| preservation | PASS | `docs/archimate/processing/publishing/1.0.9/validation/rad109-preservation-final.json.gz` |
| publication | PASS | `docs/archimate/processing/publishing/1.0.9/validation/rad109-publication-check.log.gz` |
| rads | PASS | `docs/archimate/processing/publishing/1.0.9/validation/rad109-rads.log.gz` |
| release | PASS | `docs/archimate/processing/publishing/1.0.9/validation/rad109-release.log.gz` |
| serialization_roundtrip | PASS | `docs/archimate/processing/publishing/1.0.9/validation/serialization-diagnostic.json.gz` |

The complete generated set contains 15 outputs: the original 14-output publication
set plus the accepted Product Markdown catalogue. Independent reproduction checks
every output, including this report and the guide, byte-for-byte. Reproduction
evidence is recorded separately to avoid a circular self-attestation.
See [independent reproduction evidence](validation/reproduction.json).

Open Exchange publication: [Harmonia-Architecture-1.0.9.xml](../../../exchange/publish/1.0.9/Harmonia-Architecture-1.0.9.xml).
SHA-256: `9f120d6fc36d7e659f3799b0af5f7c1d4544b6591abd31e45ccb7393fb0162af`.
Resource source: `docs/markdown/governance/baseline/accepted-ingestion-1.0.8.json`.
RAD release 1.0.9 follows architecture baseline 1.0.8; the preserved governance/
tooling sequence through 1.0.14 does not determine this architecture number.

Real Archi 5.10 no-edit CLI import/export and schema validation completed.
All 1,308 identities and naming Properties, native element/relationship content,
212 Home assertions and the four accepted authored Views survive. Raw comparison
remains **DIFFERENCES**: its 1,669 semantic-text findings are exactly identical to
the established 1.0.7 transport evidence. Organisation IDs/order, default styles
and other raw transport findings remain visible; no equivalence rule was added.
This is not a claim of whole-model lossless fidelity.
Human rendering acceptance remains **PENDING INSPECTION**. No Information or
Application Architecture work was commenced.

The [inspection guide](archi-inspection-guide.md) and
[real Archi transport evidence](roundtrip/archi-transport-verification.json) retain
that separate handoff gate. The recorded actual export and native Archi model,
raw comparator, CLI logs and read-only verification probe are in `roundtrip/`.
The mechanical reconciliation, publication and validation scope ends here.
