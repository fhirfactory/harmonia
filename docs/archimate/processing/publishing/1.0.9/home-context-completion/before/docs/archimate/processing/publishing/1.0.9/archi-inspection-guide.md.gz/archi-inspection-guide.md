<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

# Archi handoff — RAD-1.0.9

Import `docs/archimate/exchange/publish/1.0.9/Harmonia-Architecture-1.0.9.xml`
into Archi 5.10 as a fresh complete model. Expected SHA-256:
`9f120d6fc36d7e659f3799b0af5f7c1d4544b6591abd31e45ccb7393fb0162af`.

Inspect the four accepted authored Views and their original geometry. Verify the
four Association «Home» edges coexist with the native Realizations. Check the new
Product metadata and the Identifier Capture CT3 Composition. Check unrelated Views
and existing identities remain intact. Native Products and uncontained behaviours
retain authored presentation without inferred naming or semantic ancestry.

The recorded real CLI no-edit round trip is in the accompanying transport evidence.
Human import/rendering acceptance is still pending. For a further human no-edit
probe, export the complete model including every View and folder
organisation, with English language `en` and validation enabled. Preserve the raw
export and record the actual operator/version/profile. Run the existing
`diagnose_roundtrip.py compare` on the published/exported pair, with diagnostic
output under `/tmp` or `.junie/reports`. Review all semantic, metadata, relationship,
View and presentation findings. Do not report an actual Archi round trip until
that evidence exists. Current human state: **PENDING INSPECTION**.
