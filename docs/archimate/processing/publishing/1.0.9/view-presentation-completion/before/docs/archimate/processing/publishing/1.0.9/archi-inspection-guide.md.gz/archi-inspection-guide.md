<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

# Archi handoff — RAD-1.0.9

Import `docs/archimate/exchange/publish/1.0.9/Harmonia-Architecture-1.0.9.xml`
into Archi 5.10 as a fresh complete model. Expected SHA-256:
`efe3b986ae3e031d35bf38e7af47bb733af090dab63e46726f21b4e0a557cfec`.

Inspect the four accepted authored Views and their original geometry. Verify the
four Association «Home» edges coexist with the native Realizations. Check the new
Product metadata and the Identifier Capture CT3 Composition. Check unrelated Views
and existing identities remain intact. Inspect Identifier Create, Identifier Update,
Identifier Verification and Verify Identity Source under their explicit Home Features.
Inspect Maintain Clinical Privileges and Clinical Privilege Verification under their
Home context while confirming unchanged responsibility Properties. All 212 Home
sources use the same governed context for both names and resource navigation.
The 111 unresolved Home cases retain their existing locations. Native Products
retain their independently governed names and authored presentation.

The recorded real CLI no-edit round trip is in the accompanying transport evidence.
Human import/rendering acceptance is still pending. For a further human no-edit
probe, export the complete model including every View and folder
organisation, with English language `en` and validation enabled. Preserve the raw
export and record the actual operator/version/profile. Run the existing
`diagnose_roundtrip.py compare` on the published/exported pair, with diagnostic
output under `/tmp` or `.junie/reports`. Review all semantic, metadata, relationship,
View and presentation findings. Do not report an actual Archi round trip until
that evidence exists. Current human state: **PENDING INSPECTION**.
