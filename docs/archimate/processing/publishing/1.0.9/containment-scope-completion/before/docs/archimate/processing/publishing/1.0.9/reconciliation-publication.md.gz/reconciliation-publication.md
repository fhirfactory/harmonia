<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

# RAD-1.0.9 — reconciled candidate with generated View presentation

The unsigned candidate incorporates all 32 accepted ingestion CRs and the completed
Home-derived naming/navigation work. This subsequent task changes generated View
presentation only. Final Solution Architect import/rendering inspection is pending.

Model: `docs/archimate/exchange/publish/1.0.9/Harmonia-Architecture-1.0.9.xml`. SHA-256: `b9c63aef051f5424b937c7b01951cabd38389c4352610a8331a0d40e449dbf24`.

| Measurement | Result |
| --- | ---: |
| Elements / native relationships / Views | 1,308 / 1,077 / 1,198 |
| Containment Views migrated / validated | 119 / 119 |
| Business Behaviour Views validated / changed | 61 / 19 |
| Business connections changed / validated | 29 / 136 |
| Known stale connections changed / validated | 29 / 29 |
| Protected authored presentations | 4, exact |
| Historical candidates / 21-child Views preserved | 62 / 2 |

Semantic records, identities, naming, Home/responsibility assertions, native endpoints,
navigation, View membership and visual identities are unchanged. Unselected Views
and unchanged connections retain byte-identical XML. The uncertain diagnostic and
unrelated presentation debt remain intact. Generation retains RAD-1.0.9, predecessor 1.0.8.

Containment uses the [governed archetype](../../../../markdown/governance/archimate-ingestion-publication-semantics.md#deterministic-containment-view).
Children use stable semantic-ID ordering and their actual rectangle dimensions.
Second-column routes cross first-column gaps with clearance. Native Composition
retains its source-side diamond. Business routing is recalculated from final
rectangles and changes XML only when the deterministic route differs.

Separate [presentation evidence](view-presentation-completion/README.md),
[selection](view-presentation-completion/selection.json),
[verification](view-presentation-completion/verification.json) and
[inspection guide](archi-inspection-guide.md) define the current handoff.
Earlier reconciliation and Home-completion evidence remains preserved at its
original scope, with byte-recoverable prior publication snapshots.

Archi 5.10 no-edit import/export completed within the recorded scope.
Raw whole-document comparison remains DIFFERENCES; the 1,669 historical
semantic-text findings remain identical. Whole-model lossless fidelity and
human visual acceptance are not asserted.
