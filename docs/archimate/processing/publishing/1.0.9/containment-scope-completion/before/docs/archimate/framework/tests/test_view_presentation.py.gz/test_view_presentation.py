# Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later
"""Generated geometry cannot change architecture or protected presentation."""
import copy
import hashlib
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import synchronise_baseline as s
import governed_metadata as m
import view_presentation as p


class ViewPresentationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        outputs, cls.b, cls.report = s.publish()
        cls.root = s.g.ET.fromstring(outputs[m.model_path()])
        cls.before = cls.b.view_presentation_before
        cls.scope = cls.b.presentation_scope

    def test_authorised_population_and_independent_semantic_preservation(self):
        self.assertEqual(s.load_release(), self.scope['architecture_release'])
        result = p.audit(self.before, self.root, self.scope)
        self.assertEqual((119, 61, 29, 4, 62, 2), tuple(result[k] if k != 'oversized_preserved'
            else len(result[k]) for k in ('containment_views_validated', 'business_views_validated',
            'known_stale_connections_validated', 'protected_authored_views',
            'historical_candidates_preserved', 'oversized_preserved')))
        self.assertEqual('EXACT', result['semantic_identity_metadata_and_navigation'])
        self.assertEqual('BYTE_IDENTICAL', result['unchanged_connection_xml'])
        self.assertEqual(119, result['containment_views_changed'])
        self.assertEqual(29, result['known_stale_connections_changed'])

    def test_every_selected_view_has_clear_paths_and_nonoverlapping_nodes(self):
        all_views = p.views(self.root)
        for vid in self.scope['containment']:
            p.validate_geometry(all_views[vid], containment=True)
        for vid in self.scope['business']:
            p.validate_geometry(all_views[vid])

    def test_reapplying_final_geometry_is_byte_identical(self):
        revised = copy.deepcopy(self.root)
        p.apply(revised, self.scope)
        self.assertEqual(s.g.serialize(self.root), s.g.serialize(revised))

    def test_semantic_navigation_protected_and_unselected_changes_are_rejected(self):
        protected = self.scope['protected_authored'][0]
        cases = [('a:elements/a:element/a:name', 'text'),
                 ('a:relationships/a:relationship', 'target'),
                 ('a:organizations/a:item', 'identifier'),
                 (f'a:views/a:diagrams/a:view[@identifier="{protected}"]/a:node', 'x')]
        for xpath, field in cases:
            root = copy.deepcopy(self.root)
            item = root.find(xpath, s.g.N)
            self.assertIsNotNone(item)
            if field == 'text':
                item.text = 'unapproved'
            else:
                item.set(field, 'unapproved')
            with self.assertRaises(ValueError):
                p.audit(self.before, root, self.scope)

    def test_routing_obstruction_and_endpoint_change_are_rejected(self):
        vid = next(iter(self.scope['containment']))
        for field, value in (('source', 'missing'), ('relationshipRef', 'missing')):
            root = copy.deepcopy(self.root)
            p.views(root)[vid].find('a:connection', s.g.N).set(field, value)
            with self.assertRaises(ValueError):
                p.audit(self.before, root, self.scope)
        root = copy.deepcopy(self.root)
        view = p.views(root)[vid]
        connection = view.find('a:connection', s.g.N)
        nodes = {n.get('identifier'): n for n in view.findall('a:node', s.g.N)}
        # Going through the source centre violates its boundary independently
        # of schema/reference validity.
        p.set_bends(connection, [p.centre(p.rect(nodes[connection.get('source')]))])
        with self.assertRaises(ValueError):
            p.audit(self.before, root, self.scope)

    def test_route_recalculation_does_not_rewrite_an_unchanged_connection(self):
        connection = s.g.ET.fromstring(b'<connection xmlns="http://www.opengroup.org/xsd/archimate/3.0/" identifier="c">\n <bendpoint x="5" y="7"/>\n</connection>')
        before = s.g.ET.tostring(connection)
        self.assertFalse(p.set_bends(connection, [(5, 7)]))
        self.assertEqual(before, s.g.ET.tostring(connection))

    def test_odd_sized_nodes_attach_at_the_actual_rectangle_boundary(self):
        box = (17, 23, 225, 83)
        for toward in ((-100, 50), (400, 90), (50, -100), (80, 500)):
            x, y = p.boundary(box, toward)
            self.assertTrue(17 <= x <= 242 and 23 <= y <= 106)
            self.assertTrue(any(abs(a-b) < 1e-8 for a, b in ((x,17), (x,242), (y,23), (y,106))))

    def test_all_counts_and_variable_node_sizes_obey_the_governed_archetype(self):
        for count in range(1, 21):
            view = s.g.ET.Element(s.g.tag('view'))
            s.g.child(view, 'node', identifier='parent', elementRef='source', x='20', y='10', w='310', h='110')
            for i in range(count):
                s.g.child(view, 'node', identifier='node'+str(i), elementRef=f'child-{i:02d}',
                          x='20', y='10', w=str(220+i*5), h=str(80+i*3))
                s.g.child(view, 'connection', identifier='conn'+str(i), source='parent', target='node'+str(i))
            p.containment_layout(view)
            p.validate_geometry(view, containment=True)
            before = s.g.ET.tostring(view)
            p.containment_layout(view)
            self.assertEqual(before, s.g.ET.tostring(view))
        s.g.child(view, 'node', identifier='overflow', elementRef='extra', x='20', y='10', w='300', h='100')
        s.g.child(view, 'connection', identifier='overflow-edge', source='parent', target='overflow')
        before = s.g.ET.tostring(view)
        with self.assertRaisesRegex(ValueError, 'Unsupported Containment'):
            p.containment_layout(view)
        self.assertEqual(before, s.g.ET.tostring(view))

    def test_historical_home_contract_remains_independently_validated(self):
        import home_context
        result = home_context.audit(self.b, self.root)
        self.assertEqual(212, result['counts']['applicable'])
        self.assertEqual(hashlib.sha256(s.g.serialize(self.root)).hexdigest(), result['published_sha256'])
        self.assertIn('separately validated', result['unrelated_architecture_and_all_views'])
        self.assertEqual(1308, m.validate_publication(self.b, self.root)['valid_canonicalId'])
