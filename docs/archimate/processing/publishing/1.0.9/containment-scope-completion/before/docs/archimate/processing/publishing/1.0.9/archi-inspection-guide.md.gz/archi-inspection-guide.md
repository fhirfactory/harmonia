<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

# Solution Architect inspection — unsigned RAD-1.0.9

Import `docs/archimate/exchange/publish/1.0.9/Harmonia-Architecture-1.0.9.xml` into Archi 5.10 as a fresh complete model.
Expected SHA-256: `b9c63aef051f5424b937c7b01951cabd38389c4352610a8331a0d40e449dbf24`.

Inspect Containment source-left orientation and the source-side diamond. Check
one-column and two-column examples, second-column offsets and unobstructed routes.
Inspect Business Feature columns and the recalculated routes. Confirm the four
protected authored presentations retain their geometry, styling and relationships.
The two 21-child Views, 62 historical candidates and uncertain diagnostic are preserved.

Representative Containment Views (name / View ID / selected children):

- 0-Financial & Commercial Services — CT3 Landscape / `id-77e7ed15646d545eb09a93cb4c92b4fb` / 1
- 0-Clinical Technology Management — CT3 Landscape / `id-fa868336acaa5fc8909d2d81e943273a` / 8
- 0-Care Administration Enablement — CT2 Landscape / `id-c4f105aa310157b7b66f14c813e35bb2` / 13
- 0-Clinical Service Dependency Management — CT2 Landscape / `id-8dcfb8d2aa6e52c4a2090a8114b987e8` / 16

Protected authored Views:

- Identifier Capture - Feature realisation / `id-216c4ab0757b45b3894e7e0c2594b9f9`
- Identity Source & Correction Lineage - Feature realisation / `id-8fb2f8b1776f4ebf969e9b5b638e4ed3`
- 0-Entity Information Enablement — CT2 Landscape / `id-c8ec850977565a17869af357ee28d917`
- 0-Person Identity Administration — Feature Landscape / `id-e2a326c7d36751af9076a32dabe0e9cd`

The complete View and per-connection changes are in
[the separate presentation record](view-presentation-completion/README.md).
The recorded CLI probe establishes transport and geometry preservation; human
rendering acceptance remains **PENDING SOLUTION ARCHITECT INSPECTION**.
No Information/Application Architecture expansion or >20-child adjudication is included.
