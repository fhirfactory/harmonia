<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

# Information Architecture machinery-validation run-002 — reusable Praxis and generated Element navigation

## Result and inspection boundary

The governed **Harmonia ArchiMate Round-Trip Engineering Praxis** is established in
[RADS](../../docs/markdown/governance/archimate-round-trip-engineering-praxis.md),
and Run-002 now regenerates the complete Element navigation population from the
shared state-filtered containment model and governed collection classifications.
The previous runner regenerated only the 86 Information Architecture Elements;
it retained other Element placement and required incoming collection scaffolding.
Retained folders could not prove complete generation. The correction is in shared
framework capabilities, context and regressions, rather than an IA-specific fix.

The principal [candidate.xml](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/candidate.xml)
is plain Open Exchange XML, ready for Solution Architect inspection in Archi.
It remains **PROPOSED; NOT ACCEPTED; NOT A RAD RELEASE**. Its exact hash, size and
final test results are recorded in the validation section below.

This remains **Run-002** against **RAD-1.0.10**, predecessor **1.0.9**. No Run-003,
RAD-1.1.0, final reconciliation, canonical-ID allocation, Documentation cleanup,
Archi import/round-trip or architectural acceptance was performed.

## Repository discovery, authority and checkpoints

| Required part | Established location and behaviour |
| --- | --- |
| Praxis definition | [archimate-round-trip-engineering-praxis.md](../../docs/markdown/governance/archimate-round-trip-engineering-praxis.md) defines purpose, actors, authority, stages, inputs/outputs, checkpoints, stop/recovery conditions and release management. It composes existing contracts instead of reproducing a procedural script. |
| Agent discovery | Root [AGENTS.md](../../AGENTS.md#archimate-round-trip-task-entry), [governance index](../../docs/markdown/governance/README.md), [architect entry](../../docs/archimate/README.md#round-trip-engineering-requests), existing authoring Praxis and framework README link to the maintained RADS contract. No conversation or Junie report is an architectural prerequisite. |
| Review trigger | `Model Updated. Please review and generate change-review.md.` The agent discovers exact baseline/export provenance, validates, observes and prepares independently adjudicable CRs under the existing template. Explicit locators resolve ambiguous inputs; timestamps and backup filenames do not supply authority. |
| Change Review checkpoint | Human `change-review.md`: changed/unchanged architecture, new/deleted/evolved elements, preserved/rebound identities, relationships, derived consequences, metadata/navigation, Views, validation, ambiguities, adjudication and proposed deterministic directives. Default On-Hold/Unresolved and Not authorised; detection applies nothing. |
| Directive/application trigger | `change-review.md reviewed and updated. Apply directives.` The reviewed document supplies human adjudication, subject to exact input applicability, decision-linked instructions, prerequisites, resulting state and higher authority. Ambiguous/inconsistent directives stop affected execution. |
| Application checkpoint | `roundtrip_praxis.inspect_review` pins the reviewed bytes to the baseline/export hashes. The authorised agent must then validate the actual CR instructions, dependencies and expected state under the existing Change Review contract. Hash applicability alone never authorises execution. |
| Release boundary | The governed release policy's existing RAD-1.0.10 exception includes supporting Praxis/governance changes. Processing attempts consume no RAD versions. Actual Archi proof and Solution Architect acceptance precede the separately governed publication/release transition. |

AX-04, AX-14, AX-15 and AX-17 materially govern this work: reuse suitable
machinery; preserve semantics/representation/projection/presentation and
execution-result distinctions; preserve uncertain effects; and reserve
architectural adjudication to the Solution Architect. The current 2026-10-20
clarification is recorded in RADS, with explicit precedence over earlier broad
Composition wording and earlier preservation of unresolved navigation locations.
No legacy architectural description was promoted into RADS without review.

The linked historical `ingestion/1.0.8/run-002/change-review.md` remains a different
review transaction. It was read for context and not modified or applied to this
Information Architecture specimen. A reviewed filename from another transaction
cannot confer applicability to the RAD-1.0.10 input pair.

## Shared framework and current interpretation

| Component | Reused or extended responsibility |
| --- | --- |
| `roundtrip_praxis.py` | Reusable unique discovery, comprehensive read-only comparator/intake orchestration and reviewed-document applicability checkpoint; identifies the review contract, template and required evidence. It does not guess CR granularity or parse prose into architectural authority. |
| `diagnose_roundtrip.py`, `change_review.py`, `element_correlation.py` | Existing offline XML/reference checks, exhaustive representation/presentation comparison, canonical-first continuity and rebinding evidence. Native Composition observations remain distinct from effective current containment. |
| `relationship_state.py`, `containment.py` | Existing shared standing selection, type-selected Home/Composition resolution and single ancestry engine. Run-002 resolves once and passes that model to its consumers. |
| `governed_metadata.py`, `information_naming.py` | Existing lexical/qualified-name machinery and authored native type/Name/specialisation interpretation. Submitted derived claims remain evidence; they do not override semantics. Run-001 proposed metadata is still reproduced byte for byte. |
| `workspace_policy.py` | Collection classification from resource-owned RADS records by canonical identity. Current semantic ancestors take precedence over stale recorded category/owner context. Recorded context may recover a collection category only; it never inserts an absent current parent. New unmapped classifications stop explicitly. |
| `workspace_navigation.py` | Shared projector now creates absent anchors/references, regenerates all declared Element and Relations branches and preserves Views. Tests and reusable counterfactual proof remove or misplace all input folders. |
| `run_evidence.py` | Common create/check/guarded-correction writer. Checks archived manifest and every original generated output before any correction write, rejects stale archives/path escapes and performs no release allocation. The former one-time `--correct-run-002` branch is replaced by reusable `--before-archive`. |
| `governance_history.py`, `governance-transitions.json` | Exact, registered before/after governance transitions with hash-verified snapshots; frozen source pins remain unchanged. Historical replay accepts only the recorded chain and rejects arbitrary edits or snapshot drift. |
| Existing resource/reconciliation/publication tools | Retain their bounded accepted scopes. They are adapters available to the governed agent, not a universal unattended reconciliation engine. |

**Home is the default**, explicitly directed native Association specialised as
Home, contained element → home. **Composition exceptions are selected by the
contained element's native type:** Capability (including Feature), BusinessObject,
DataObject (including Topic), Artifact. Feature inherits Capability; explicit Topic
specialisation inherits DataObject. Bracketed labels, stale derived Properties,
ordinary Association, Realization, folders and Views establish no containment.
Current/historical relationship standing is resolved before ancestry.

The specimen still selects **212 Home** and **632 Composition** relationships,
excludes **121 preserved historical assertions** and has **zero current
containment findings**. All assertions remain in XML. The old 61 direct / 109
propagated findings remain resolved by historical filtering; no parent is chosen
from competing current assertions. Conditional proposals are not accepted facts.

## Generated Element and source-organised Relationship navigation

The complete **1,394-element** population is generated. The immutable export's
Element or Relationship folders supply neither ancestry nor a generation oracle.
Collections use governed native/category/standing roles. Composition/Home parents
with children receive context folders containing themselves and direct leaves;
deeper contexts nest recursively. Business Home projections use the Business
context and Functions/Processes/Services roles. A missing current Feature parent
or Business Home is exposed under `Unresolved Feature Ancestry` or `Unestablished
Home`, respectively. These navigation labels assert no semantic parent or root.
Existing names and relationship standing remain unchanged by that projection.

In particular, the existing 173 Feature elements without native Composition are
not silently attached through their recorded owners. The 111 Business behaviours
without explicit Home are not given inferred Homes or current owner containment.
Their prior source-qualified names remain unchanged historical naming evidence.
Collection classification and actual current containment remain separate.

| Generated measure | Result |
| --- | ---: |
| Element navigation references / retained Element references | 1,394 / 0 |
| Elements with selected current containment | 844 |
| Containment roots with children / uncontained standalone Elements | 149 / 401 |
| Maximum selected containment depth, edges | 4 |
| Element context/role folders | 626 |
| Relationship-source contexts | 493 |
| Relationship mirror folders | 538 |
| Relationship references, exactly once | 1,137 |
| Existing Views, preserved | 1,209 |

Legacy JSON summary keys named `composition_*` now describe the shared selected
containment paths; they are retained for evidence compatibility and do not imply
Composition for Home-governed elements or semantic root completeness.

The 86-element IA subset retains its intended Composition hierarchy, including
the Individual parent/self and Authority, Contact, Demographics, Identity,
Patient, Person and Relationship children. CommunicationAddress follows Workforce
Composition; Equipment Aggregation establishes no parent. The collection anchors
remain Business/BusinessObjectMap, Application/InformationMap and
Technology & Physical/DataMap. There is no Artifact population.

Relationships remain source-organised for all 1,137 native records, including
historical ones. Their paths mirror the actual source's generated Element location;
source contexts are reused and leaf sources get their own context. Type and target
choose no home. Paths change where formerly retained Element navigation is now
regenerated; this preserves the successful Run-002 source-based behaviour rather
than preserving accidental old folders. Projection IDs remain separate from
canonical architectural identity and allocate none.

## Proof of generation, semantics and Views

[Element generation proof](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/element-generation-proof.json)
records two independent in-memory input variants:

1. Remove every Element and Relationship folder, collection anchor and navigation
   reference; keep the authored semantic architecture and Views.
2. Replace Element navigation with one deliberately misleading flat folder and
   omit Relationship navigation.

Both regenerate the **exact same complete organisation** as the principal
candidate, with 1,394 generated Element references. Protected content is unchanged.
This establishes generation from semantics/configuration; it does not infer
generation from structures already present in the submission. Regression tests
also change an actual relationship while retaining old folders and require the
new semantic hierarchy to change the generated output. The submission file is
never edited for these counterfactuals.

All **1,209 Views** survive with exact XML-content signatures, including identities,
membership, nodes/nesting, connections, order, layout/geometry, styles, annotations,
Documentation and residual governed content. The **complete Views navigation
subtree** is also unchanged. View signature SHA-256:
`7884117cd23076e1c21e69a886287e642e6ab76675a0767619e21488d05c146b`.
View-navigation signature SHA-256:
`863be1b0b47f7e273c1d5b9a9353c180eea6f1340748cb5b94875313531670ca`.

The naming allowlist verifier restores only allowed metadata/Names and the
candidate marker to compare protected authored content. Restoring only the
original organisations then invokes that verifier against the immutable architect
submission. No semantic element, relationship, endpoint, direction, specialisation,
canonical identity, Documentation or View is changed by navigation generation.

The already-passing behaviours are retained: `[BusinessObject]` and `[Topic]`
naming; explicit Topic/native DataObject; **38 representation rebindings** with
canonical continuity; **1,362 canonical matches**; **32 absent new canonical IDs**
without allocation; four explicitly unresolved legacy DataObject classifications;
shared state-filtered containment; and actual-source relationship navigation.
Both Run-001 proposed metadata and rebinding evidence remain byte-identical.

## History and reproduction

The previous report and machinery/output state are preserved unchanged in
[pre-element-projection-correction](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/validation/pre-element-projection-correction/manifest.json).
The earlier pre-containment archive and diagnostic are retained as history.
The first generated Element correction is additionally archived under
`validation/pre-context-completion/` before completing navigation-governance context
and the current-ancestor classification regression. `validation/pre-view-navigation-guard/`
also retains that generated state before adding the fail-closed guard against
discarding unestablished View navigation. All attempts remain Run-002.
No historical pin, input or Run-001 result was rewritten to make a check pass.

The old `validation/verify_containment_correction.py` and its logs describe the
previous byte-identical-candidate correction; they are historical, not the current
Element-generation acceptance check. Current verification uses `--check`, the
updated isolated replay, counterfactual generation proof and the regression suite.
Archived machinery includes tools, schemas, tests, governing context and collection
source snapshots. Isolated replay restores those sources/configuration without
importing live processing modules and compares candidate, metadata, containment,
navigation, rebinding identity fields and generation proof.

## Validation results

Candidate SHA-256: `a451a6358e9c28ee95a2f14e339c01024ed7ea955d978d9fedaf8619be04c73f`.
Size: **22,215,629 bytes**. It differs from the old candidate because Element and
Relationship navigation is now regenerated for the complete population.

All commands ran from the repository root with explicit TERM/KILL bounds.

| Check | Result |
| --- | --- |
| `timeout --signal=TERM --kill-after=5s 600s python3 -B -m unittest discover -s docs/archimate/framework/tests -v` | **PASS — 311 tests, 346.874 seconds**, no failures/errors. |
| Final workspace regression invocation, `-p 'test_workspace*.py'`, 180-second bound | **PASS — 32 tests, 35.751 seconds**, including the final current-ancestor precedence and fail-closed View-navigation guard additions. |
| Praxis discovery/intake/review applicability and registered governance history, 120-second bound | **PASS — 5 tests**. |
| Shared guarded evidence writer, 120-second bound | **PASS — 4 tests**. |
| `timeout --signal=TERM --kill-after=5s 300s mvn test -pl paradeigma/paradeigma-test -am '-Dtest=*ArchitectureTest' -Dsurefire.failIfNoSpecifiedTests=false` | **PASS — 90 tests**, no failures/errors/skips; Maven 18.299 seconds. |
| Guarded final Run-002 regeneration, 120-second bound | **PASS** — archived preconditions verified before generated outputs were replaced. |
| Live `information_workspace_run.py --check`, 120-second bound | **PASS** — every generated byte and live machinery fingerprint reproduced. |
| Isolated `validation/reproduce_candidate.py`, 120-second bound | **PASS** — archived sources/configuration reproduce candidate, naming, navigation, containment and generation proof byte for byte; 38 rebinding identities preserved. |
| Missing/misleading folder counterfactuals | **PASS** — both regenerate the exact same complete organisation; immutable input untouched. |
| Offline XSD, identifiers/references, unique navigation, naming allowlist and protected semantic/View content | **PASS**, in candidate generation and independent regression/replay checks. |
| Frozen inputs and archived originals | **PASS** — 28 protected file hashes; 130 pre-containment, 120 pre-Element, 92 pre-context and 93 pre-View-guard archived files verified. |
| Source/output integrity, local Praxis/report links and `git diff --check` | **PASS**. |
| Actual Archi import/rendering, complete-model transport and architectural acceptance | **PENDING SOLUTION ARCHITECT** — not performed or claimed. |

The complete framework invocation precedes the last two focused regression
additions; the final 32-test workspace invocation exercises those final source
changes. No suite is reported as testing code that was not loaded by that run.
The first full invocation ran 230 tests and reported ten setup/errors in 81.657
seconds because historical authority pins correctly rejected the new root/context
documentation. Exact registered before/after transitions were added and verified;
the unchanged original pins remain authoritative historical evidence. This was a
governance replay prerequisite, not a production architecture failure, timeout or
stall. The later full suite passed. Both logs are retained distinctly.

Current logs and audit data are under
[validation/praxis-correction](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/validation/praxis-correction/).
The [current validation manifest](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/validation/manifest.json)
identifies the candidate, final checks and preserved historical evidence. Its
[integrity audit](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/validation/praxis-correction/integrity-audit.json)
checks all generated output hashes and live/archived machinery sources, all frozen
inputs, the release authority and absence of Run-003/RAD-1.1.0 artefacts.

## Remaining two-trigger proof and stop point

The two triggers are now discoverable as a governed **agent-operated** workflow.
Discovery/intake, shared derivation, navigation generation and review applicability
have reusable tools and regression proof. The agent still decomposes architectural
CRs and checks reviewed prose under the governed contract; the helper deliberately
does not infer authority or implement a universal prose-to-reconciliation engine.
Existing reconciliation adapters are scope-specific. Future approved changes
outside their coverage require shared implementation/regressions or explicit
adjudication, not hidden run scripts or invented architectural meaning.

End-to-end directive application/publication for this Information Architecture
submission remains **unproven and unauthorised in this task**. The four legacy
DataObject classifications remain uncertain; 32 new canonical identities remain
unallocated. The Solution Architect must inspect the corrected candidate in Archi;
a later actual complete-model export must establish transport fidelity and the
required review, directive, validation and acceptance gates must complete before
final reconciliation/publication or RAD-1.1.0. No input modification or manual
repair of derived metadata is requested of the Solution Architect.

Stop here with the corrected Run-002 candidate ready for architectural inspection.
