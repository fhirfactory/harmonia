<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

# Information Architecture machinery-validation run-002 — workspace organisation

## Result and scope

Run-002 produces the proposed plain-XML candidate at
[candidate.xml](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/candidate.xml).
It projects explicit Composition into IA Elements navigation and organises every
relationship by its actual source element. The candidate retains **1,394 semantic
elements, 1,137 semantic relationships and 1,209 Views**. No architectural element
or relationship was added, removed, merged, reversed or retyped for navigation.

The candidate SHA-256 is
`589759a0dbca2fb19f5a263a65309cc94fa10260797299d6c7e245061a828599`.
It is **22,337,917 bytes of plain Open Exchange XML** and requires no decompression
before Archi import. Its standing remains **PROPOSED; NOT ACCEPTED; NOT A RAD
RELEASE**. Actual Archi import, human workspace inspection, complete-model round
trip and Solution Architect acceptance remain subsequent gates.

AX-04, AX-14 and AX-17 govern this implementation: machinery projects semantic
architecture, preserves distinctions and does not choose uncertain architecture.
The current naming, source-based relationship-home and machinery-validation rules
are applied without amending RADS. The explicit run-cycle exception governs the
release boundary. RAD remains **1.0.10**, predecessor **1.0.9**; no RAD-1.1.0 was
created. Architecture reconciliation and **Documentation cleanup remain deferred**.

## Frozen inputs and preservation

The shared specimen manifest remains unchanged. Its inputs are:

| Input | Repository path | SHA-256 |
| --- | --- | --- |
| Published RAD-1.0.10 baseline | `docs/archimate/exchange/publish/1.0.10/Harmonia-Architecture-1.0.10.xml` | `b1036f745e8ae3754951cd123b2b1a54a7eaa76c5fa83933abbd11ff2d4153bc` |
| Immutable architect-authored Exchange submission | `docs/archimate/exchange/ingest/1.0.10/harmonia-architecture-1.0.10.xml` | `034dd70974245523ec11b503a9cf0535827d9ff6f161cafcabf002555dbf16ed` |
| Existing no-edit Archi control, gzip bytes | `docs/archimate/processing/publishing/1.0.10/information-population/canonical-name-completion/roundtrip/Archi-no-edit-export.xml.gz` | `1e2ecfb5585448c84eb009d22c9d1f7794d8e452f6d841865e08d675526aca8d` |
| No-edit control, decompressed XML | Same control | `ac7fad3d30b230e894fa12e64e74e77939fc6574dd3336a8ddd7569f70c22b65` |

Additional protected files include:

| File | SHA-256 |
| --- | --- |
| Architect's native `Harmonia Architecture-1.0.10.archimate` | `7c0a833f1ab0f0e5c789bfec50908c7daabc6013777a9f7731a9f8a7e07503de` |
| Native `.archimate.bak` | `d6debc863310e50e27332e52f9d7f964e9be81f66bb8170c01fa9392e4e4ffbf` |
| Run-001 `candidate.xml` | `4bd981b239393c1ce09d5a831b52b1ebe82daf4807139e5414c25ec3e91a28a3` |
| Run-001 `manifest.json` | `2b14bb863beb6029490863bc8a08d7fad134988bee091b93d384f8736af541c3` |
| Root `architecture-release.json` | `3ab2fd7b2b73733e2b4149fc4c682a8f0bf110c80b3543cf51200ebce3f47214` |

A task-start audit pinned **28 files**, covering the published baseline, the whole
1.0.10 submission directory, all Run-001 evidence, its report, the shared specimen
manifest and release authority. The final audit confirms all 28 byte hashes remain
unchanged. The generator also compares its own before/after frozen-file maps and
checks all three specimen hashes, including decompressed control bytes.

The run's [manifest.json](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/manifest.json)
retains those paths, hashes, machinery fingerprints and generated-output hashes.
The task-start/final audit and command evidence are retained under `validation/`.
No Run-001 evidence or historical fingerprint was rewritten.

## Run-001 behaviour retained

The existing Run-001 naming resolver and runner were left unchanged. Run-002
regenerates their proposed metadata and requires exact byte equality with Run-001's
`proposed-metadata.json`. Its pre-navigation tree also matches Run-001 after only
changing the explicit run-standing marker.

The candidate retains the `[BusinessObject]`, `[Topic]` and `[Artifact]` naming
rules, native types, explicit Topic specialisation, Composition ancestry,
semantic relationships and deterministic metadata derivation. The submitted
population contains **12 BusinessObjects, 70 explicitly specialised Topics and
four unresolved legacy DataObjects**; there are no Artifacts. Artifact behaviour
is covered by synthetic regression cases without creating physical architecture.

All **1,362 existing model-wide canonical identities**, including the **54 existing
information identities**, remain intact. All **38 representation rebindings**
are preserved in an exact copy of Run-001's rebinding evidence. The **32 new
elements retain absent canonical IDs**. The four legacy DataObjects retain their
existing classification uncertainty and submitted claims. No identity was
allocated, and no metadata or semantic acceptance was inferred from the run.

Model Documentation, relationship Documentation, complete Views, visual nodes,
connections, geometry, presentation properties and the existing Views organisation
are preserved. Only the naming changes already established by Run-001, candidate
standing and the authorised Elements/Relations navigation are allowed to differ
from the immutable architect submission.

## Element navigation rule

[workspace_navigation.py](../../docs/archimate/framework/tools/workspace_navigation.py)
accepts a declared native-type population and collection anchors. Run-002 applies
it to all native BusinessObjects, DataObjects and Artifacts, independently of
classification resolution or domain names. Their established presentation anchors
are `Business/BusinessObjectMap`, `Application/InformationMap` and
`Technology & Physical/DataMap`. Other Elements navigation is retained.

Only explicit native **Composition source → target** supplies ancestry. The
resolver recognises both unqualified and namespace-qualified native type names.
It reads no folder, View, geometry, Grouping, Aggregation, Specialization,
Realization, Association or lexical-similarity evidence to establish containment.

An element with Composition children receives a same-named context folder,
containing its own architectural reference and direct leaf references. A child
with descendants receives its own context folder, recursively. The algorithm
walks ancestry iteratively, has no one-level assumption and is tested through
eight levels and an alternate declared Capability population.

The resulting Individual context contains the actual `[Topic] Individual` plus
Authority, Contact, Demographics, Identity, Patient, Person and Relationship.
These are existing elements, each referenced once. The enclosing folder is
navigation only. The prior authored folder of each IA element is discarded as an
ancestry input; changing that folder nesting leaves the derived result unchanged.

A Composition root receives its context directly below its native collection.
An element with neither a Composition parent nor children remains a direct
reference in that collection. Absence of a submitted parent establishes no claim
of complete architectural root status. Cross-layer populations may mirror actual
ancestor contexts under each native collection without moving or retyping the
architectural ancestor into another native category.

Competing parents, duplicate Composition assertions, cycles, self-cycles, missing
endpoints or containment crossing the declared population stop generation before
run outputs are written. No arbitrary parent or partial hierarchy is selected.
Missing/ambiguous collection anchors, canonical identity claims, element homes or
XML projection identifiers also stop generation. These outcomes are regression
tested and do not trigger architectural repair.

## Relationship source-context rule

Every semantic relationship receives exactly one reference under `Relations`,
mirroring its **actual source element's resulting navigation path**. A projected
Composition parent's own context is reused. For a leaf, standalone or non-IA
source, a source-element folder is added beneath that path. Thus leaf relationships
can grow without becoming mixed with every other source in their collection.

The relationship type and target do not select the folder. Relationships are
neither repeated beneath targets nor merged by matching endpoints. Existing
non-IA source locations supply retained presentation context; they do not become
newly inferred semantic ancestry. Empty Relations branches are omitted.

The **Workforce → CommunicationAddress Composition** and **Equipment →
CommunicationAddress Aggregation** retain their original types, identities and
directions. CommunicationAddress belongs in the Workforce element context; the
Aggregation appears under Equipment's relationship-source context. No symmetry
was manufactured.

The current model has 493 sources with outgoing relationships, including the
eleven IA roots. The largest source has 26 outgoing relationships. Synthetic
tests cover outgoing relationships from deeper leaves and multiple relationship
types, independently of the present one-level IA population.

## Deterministic projection identity and counts

Workspace IDs use the separate, versioned `workspace-` namespace, derived from
SHA-256 of model identity, projection version, role and stable context key. A
semantic context uses unique canonical identity when available; otherwise it
explicitly uses the element's frozen representation identity. The native
collection distinguishes projection roles. Labels and Composition ancestry are
excluded from element-context identity, so renaming, canonical representation
rebinding and reparenting preserve that context ID within its collection.

Retained scaffold mirrors use existing folder identity or, where the export omits
it, the explicit presentation label path. That fallback supplies no architectural
identity or containment. Relationship reference IDs use preserved relationship
representation identity. XML ID collision checks remain mandatory. Same-named
elements retain distinct identity-based contexts rather than being merged.

Sibling ordering uses labels with stable identity tie-breaks. A Composition
parent's own element is serialized first in its context. Archi's rendered sort
order remains a human inspection matter; it creates no semantic ordering.

| Measure | Result |
| --- | ---: |
| Information elements projected | 86 |
| Composition roots with context folders | 11 |
| Contained information elements | 59 |
| Non-contained standalone information elements | 16 |
| Maximum current IA Composition depth, in edges | 1 |
| Generated Elements context folders | 11 |
| Relationship-source contexts | 493 |
| Mirrored Relations path folders | 727 |
| Additional dedicated source folders | 482 |
| Total Relations folders, including category root | 1,210 |
| Relationships referenced exactly once | 1,137 |
| All workspace folders, including retained/View folders | 4,391 |
| All element, relationship and View navigation references | 3,740 |

The 493 source contexts include eleven reused Composition contexts. Consequently,
they must not be added to the 727 mirrored folders without subtracting that reuse.

## Evidence, reproduction and verification

[information_workspace_run.py](../../docs/archimate/framework/tools/information_workspace_run.py)
checks frozen inputs, repeats Run-001 naming, projects navigation and validates the
serialized/reparsed candidate. Its independent placement checker reconstructs
ancestry from Composition and checks every relationship against its actual source.
After restoring only the original organisation subtree, the established naming
allowlist verifier must reproduce the protected architect submission exactly.
This goes beyond XML/schema validity.

`workspace-projection.json` records identity-based element paths, relationship
sources/context IDs, counts and out-of-scope findings. `verification.json` records
the semantic, metadata, navigation and preservation gates. Compressed byte
snapshots under `machinery/` preserve the actual tools, schemas, tests and applicable
governance. Supplemental import-time configuration snapshots support isolated
reproduction without importing live tools.

The validation script restores those archived sources and hash-checked specimens
into a fresh temporary tree. It reproduces **candidate XML, naming metadata and
navigation evidence byte for byte**, and independently confirms the 38 rebinding
identities. Run-001's original absolute provenance locators remain untouched;
temporary replay locations are not substituted into that evidence. Live
`information_workspace_run.py --check` additionally reproduces all generated
output files and their source-fingerprint manifest without writing.

During closure, namespace-qualified native-type recognition and explicit isolated
replay instructions were added. The original source fingerprints/snapshots are
retained under `validation/development-001/` with a hash transition record. The
candidate itself remained byte-identical. No frozen input was changed.

All commands below run from the repository root with bounded execution:

| Check | Result |
| --- | --- |
| Focused workspace regressions, `timeout --signal=TERM --kill-after=5s 120s python3 -m unittest discover -s docs/archimate/framework/tests -p 'test_workspace_navigation.py' -v` | PASS — final 19 cases in 39.323 seconds, covering the closure refinements. Earlier 16- and 18-case development invocations also passed. |
| Full framework suite, `timeout --signal=TERM --kill-after=5s 420s python3 -m unittest discover -s docs/archimate/framework/tests -v` | PASS — all 276 cases discovered at invocation, 358.271 seconds; zero failures/errors. Final additional/refined cases are covered by the focused invocation above. |
| Required architecture suite, `timeout --signal=TERM --kill-after=5s 300s mvn test -pl paradeigma/paradeigma-test -am '-Dtest=*ArchitectureTest' -Dsurefire.failIfNoSpecifiedTests=false` | PASS — 90 tests; zero failures, errors or skips; Maven 19.745 seconds. |
| Generator and final read-only `--check`, each bounded to 120 seconds | PASS — candidate generated and all final generated bytes/source fingerprints reproduced without writes. |
| Isolated archived-source reproduction, `timeout --signal=TERM --kill-after=5s 120s python3 docs/archimate/processing/machinery-validation/information-architecture/run-002/validation/reproduce_candidate.py` | PASS — full candidate, metadata and navigation evidence byte-identical; 38 rebinding identities retained. |
| Offline XSD, reference/identifier validation, semantic allowlist reversal, unique homes and source/Composition placement | PASS. |
| Frozen-file audit, release check and task whitespace check | PASS — all 28 task-start hashes and the separate no-edit control preserved; release 1.0.10 / 1.0.9; no whitespace errors. |
| Actual Archi candidate import / complete no-edit round trip / acceptance | Pending Solution Architect activity; not claimed by automation. |

## Unresolved matters and inspection boundary

There is no unresolved IA containment ambiguity in this specimen. The bounded
audit does expose existing **61 non-IA elements with multiple direct Composition
assertions**, affecting **109 ancestry paths** in total. Their element homes and
semantic assertions are retained; no parent is selected or reclassified. Their
relationships still follow their retained source context. The finding list in
`workspace-projection.json` preserves the affected identities and parent
relationship IDs for a separately authorised architectural review. This run
does not adjudicate native relationship legality or architectural standing.

The four unclassified legacy DataObjects and 32 absent new canonical IDs remain
legitimate unresolved evidence. No additional IA issue requires an invented
hierarchy or reconciliation to inspect this candidate.

The Solution Architect should import the plain candidate and inspect the eleven
Topic contexts, same-named folder/element distinction, source contexts throughout
Relations, retained Views and usability under Archi's native folder sorting.
Confirm specifically that CommunicationAddress remains contained by Workforce
and merely aggregated by Equipment. Existing non-IA contexts intentionally remain
presentationally retained. A real complete-model export and comparison remain
necessary before the eventual acceptance boundary.

**Documentation cleanup remains explicitly deferred.** No Documentation quality
or consistency work was undertaken. Work stops with the Run-002 candidate,
automated evidence and this report; no architectural reconciliation, release
transition, later run or RAD-1.1.0 publication is performed.
