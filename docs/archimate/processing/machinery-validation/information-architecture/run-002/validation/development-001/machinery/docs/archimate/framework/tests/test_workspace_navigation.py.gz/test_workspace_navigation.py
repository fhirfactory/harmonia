# Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later
"""Semantic-to-workspace projection, preservation and immutable IA regressions."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / 'tools'))
import diagnose_roundtrip as d
import generate_views as g
import information_naming_run as naming
import information_workspace_run as run
import workspace_navigation as nav


class WorkspaceNavigationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='harmonia-workspace-', dir='/tmp')
        self.addCleanup(self.temp.cleanup)
        self.root = g.ET.Element(g.tag('model'), nsmap={None: g.NS, 'xsi': g.XSI}, identifier='test-model')
        g.child(self.root, 'name', 'NON-GOVERNED workspace test')
        g.child(self.root, 'elements')
        g.child(self.root, 'relationships')
        org = g.child(self.root, 'organizations')
        for layer, collection in nav.INFORMATION_ANCHORS.values():
            parent = g.child(org, 'item')
            g.child(parent, 'label', layer)
            folder = g.child(parent, 'item')
            g.child(folder, 'label', collection)
        for label in ('Relations', 'Views'):
            g.child(g.child(org, 'item'), 'label', label)
        g.child(self.root, 'propertyDefinitions')
        self.element('root', '[Topic] Individual')
        self.element('child', '[Topic] Identity')

    def anchor(self, kind='DataObject'):
        layer, collection = nav.INFORMATION_ANCHORS[kind]
        return self.root.xpath('a:organizations/a:item[a:label=$layer]/a:item[a:label=$collection]',
                               namespaces=g.N, layer=layer, collection=collection)[0]

    def element(self, rid, name, kind='DataObject', canonical=None):
        node = g.child(self.root.find('a:elements', g.N), 'element', identifier=rid, **{g.TYPE: kind})
        g.child(node, 'name', name)
        g.child(node, 'documentation', 'Keep **authored** text,\nincluding history and whitespace.')
        if kind == 'DataObject':
            naming.set_property(self.root, node, 'Specialization', 'Topic')
        if canonical is not None:
            naming.set_property(self.root, node, 'canonicalId', canonical)
        g.child(self.anchor(kind), 'item', identifierRef=rid)
        return node

    def edge(self, source='root', target='child', kind='Composition', rid='edge'):
        edge = g.child(self.root.find('a:relationships', g.N), 'relationship', identifier=rid,
                       source=source, target=target, **{g.TYPE: kind})
        g.child(edge, 'documentation', 'Untouched relationship documentation')
        return edge

    def model(self):
        path = Path(self.temp.name) / 'input.xml'
        path.write_bytes(g.serialize(self.root))
        return d.Exchange(path)

    def project(self):
        model = self.model()
        return nav.project(model, self.root)

    def home(self, root, rid):
        return nav.labels(nav.locations(root)[rid][0][0])

    def test_parent_folder_contains_self_and_direct_leaf_elements(self):
        self.edge()
        result, report = self.project()
        expected = ['Application', 'InformationMap', '[Topic] Individual']
        self.assertEqual(expected, self.home(result, 'root'))
        self.assertEqual(expected, self.home(result, 'child'))
        self.assertEqual(['Relations', *expected], self.home(result, 'edge'))
        folder = nav.locations(result)['root'][0][0][-1]
        self.assertEqual(['root', 'child'], [n.get('identifierRef') for n in folder.findall('a:item', g.N)])
        self.assertEqual(1, report['summary']['element_context_folders'])
        self.assertEqual('PASS', nav.verify(self.model(), self.root, result, report)['actual_source_navigation'])

    def test_deeper_composition_and_leaf_source_navigation(self):
        self.element('leaf', '[Topic] Identifier')
        self.edge()
        self.edge('child', 'leaf', rid='inner')
        self.edge('leaf', 'root', 'Association', 'outgoing')
        result, report = self.project()
        base = ['Application', 'InformationMap', '[Topic] Individual', '[Topic] Identity']
        self.assertEqual(base, self.home(result, 'child'))
        self.assertEqual(base, self.home(result, 'leaf'))
        self.assertEqual(['Relations', *base, '[Topic] Identifier'], self.home(result, 'outgoing'))
        self.assertEqual(2, report['summary']['maximum_composition_depth'])

    def test_non_contained_elements_remain_local_without_root_completeness_claim(self):
        self.element('artifact', '[Artifact] Package', 'Artifact')
        self.element('bo', '[BusinessObject] Person', 'BusinessObject')
        result, report = self.project()
        self.assertEqual(['Application', 'InformationMap'], self.home(result, 'child'))
        self.assertEqual(['Technology & Physical', 'DataMap'], self.home(result, 'artifact'))
        self.assertEqual(['Business', 'BusinessObjectMap'], self.home(result, 'bo'))
        self.assertEqual((0, 4), (report['summary']['element_context_folders'], report['summary']['non_contained_elements']))

    def test_aggregation_and_other_relationship_types_never_create_containment(self):
        self.edge('root', 'child', rid='contained')
        self.element('equipment', '[Topic] Equipment')
        for i, kind in enumerate(('Aggregation', 'Association', 'Specialization', 'Realization', 'Flow')):
            self.edge('equipment', 'child', kind, 'other-' + str(i))
        result, report = self.project()
        self.assertEqual(['root', 'child'], report['element_plan']['child']['composition_path'])
        for i in range(5):
            self.assertEqual(['Relations', 'Application', 'InformationMap', '[Topic] Equipment'],
                             self.home(result, 'other-' + str(i)))
        self.assertEqual(nav.protected(self.root), nav.protected(result))

    def test_misleading_authored_folder_nesting_does_not_change_derived_navigation(self):
        self.edge()
        before, plan = self.project()
        refs = nav.locations(self.root)
        misleading = g.child(self.anchor(), 'item')
        g.child(misleading, 'label', '[Topic] Equipment')
        misleading.append(refs['child'][0][1])
        after, repeated = self.project()
        self.assertEqual(plan, repeated)
        self.assertEqual(g.signature(before), g.signature(after))

    def test_views_geometry_grouping_and_documentation_are_preserved_without_containment(self):
        group = g.child(self.root.find('a:elements', g.N), 'element', identifier='group', **{g.TYPE: 'Grouping'})
        g.child(group, 'name', 'Individual Identity')
        g.child(self.anchor('BusinessObject'), 'item', identifierRef='group')
        view = g.child(g.child(g.child(self.root, 'views'), 'diagrams'), 'view',
                       identifier='view', **{g.TYPE: 'Diagram'})
        g.child(view, 'name', 'Authored nested presentation')
        visual = g.child(view, 'node', identifier='visual-root', elementRef='root', x='0', y='0', w='300', h='200', **{g.TYPE: 'Element'})
        g.child(visual, 'node', identifier='visual-child', elementRef='child', x='10', y='10', w='100', h='40', **{g.TYPE: 'Element'})
        views_folder = self.root.xpath("a:organizations/a:item[a:label='Views']", namespaces=g.N)[0]
        g.child(views_folder, 'item', identifierRef='view')
        result, report = self.project()
        self.assertEqual(0, report['summary']['element_context_folders'])
        self.assertEqual(nav.protected(self.root), nav.protected(result))
        self.assertEqual(g.signature(views_folder), g.signature(result.xpath("a:organizations/a:item[a:label='Views']", namespaces=g.N)[0]))
        self.assertEqual('PASS', nav.verify(self.model(), self.root, result, report)['protected_content'])

    def test_declared_population_is_generic_and_supports_many_levels(self):
        org = self.root.find('a:organizations', g.N)
        strategy = g.folder(org, 'strategy-folder', 'Strategy')
        collection = g.folder(strategy, 'capability-folder', 'Capabilities')
        for i in range(8):
            rid = 'capability-' + str(i)
            node = g.child(self.root.find('a:elements', g.N), 'element', identifier=rid, **{g.TYPE: 'Capability'})
            g.child(node, 'name', 'Level ' + str(i))
            g.child(collection, 'item', identifierRef=rid)
            if i:
                self.edge('capability-' + str(i - 1), rid, rid='composition-' + str(i))
        anchors = {'Capability': ('Strategy', 'Capabilities')}
        result, report = nav.project(self.model(), self.root, anchors)
        self.assertEqual(7, report['summary']['maximum_composition_depth'])
        self.assertEqual(['Strategy', 'Capabilities', *('Level ' + str(i) for i in range(7))],
                         self.home(result, 'capability-7'))
        self.assertEqual('PASS', nav.verify(self.model(), self.root, result, report, anchors)['composition_navigation'])

    def test_competing_duplicate_missing_and_cycle_inputs_stop_without_mutation(self):
        self.edge()
        self.element('other', '[Topic] Other')
        for source, target, message in (
                ('other', 'child', 'Competing/duplicate'), ('root', 'child', 'Competing/duplicate'),
                ('child', 'root', 'cycle'), ('root', 'missing', 'Missing Composition endpoint'),
                ('missing', 'root', 'Missing Composition endpoint')):
            extra = self.edge(source, target, rid='bad')
            before = g.serialize(self.root)
            with self.subTest(source=source, target=target), self.assertRaisesRegex(ValueError, message):
                self.project()
            self.assertEqual(before, g.serialize(self.root))
            extra.getparent().remove(extra)

    def test_self_cycle_and_cross_scope_containment_stop(self):
        self.edge('root', 'root')
        with self.assertRaisesRegex(ValueError, 'cycle'):
            self.project()
        self.root.find('a:relationships', g.N).clear()
        self.edge()
        with self.assertRaisesRegex(ValueError, 'outside declared projection scope'):
            nav.composition_paths({'root': object(), 'child': object()},
                                  nav.index(self.root, 'a:relationships/a:relationship'), {'child'})

    def test_projection_ids_are_separate_stable_across_rename_rebind_and_reparent(self):
        for rid, value in (('root', 'a' * 32), ('child', 'b' * 32)):
            node = self.root.find(f"a:elements/a:element[@identifier='{rid}']", g.N)
            naming.set_property(self.root, node, 'canonicalId', value)
        self.edge()
        first, report = self.project()
        root_folder = report['element_plan']['root']['context_folder']
        self.assertTrue(root_folder.startswith('workspace-'))
        node = self.root.find("a:elements/a:element[@identifier='root']", g.N)
        node.set('identifier', 'rebound')
        node.find('a:name', g.N).text = '[Topic] Renamed'
        self.root.find('a:relationships/a:relationship', g.N).set('source', 'rebound')
        nav.locations(self.root)['root'][0][1].set('identifierRef', 'rebound')
        second, report2 = self.project()
        self.assertEqual(root_folder, report2['element_plan']['rebound']['context_folder'])
        self.assertNotIn(root_folder, ('a' * 32, 'b' * 32))
        self.element('outer', '[Topic] Outer')
        self.edge('outer', 'rebound', rid='outer-edge')
        _, report3 = self.project()
        self.assertEqual(root_folder, report3['element_plan']['rebound']['context_folder'])

    def test_reordering_semantics_and_repeated_projection_are_deterministic(self):
        self.edge()
        first, report = self.project()
        for tag in ('elements', 'relationships'):
            node = self.root.find('a:' + tag, g.N)
            node[:] = reversed(list(node))
        second, again = self.project()
        self.assertEqual(g.signature(first.find('a:organizations', g.N)), g.signature(second.find('a:organizations', g.N)))
        self.assertEqual(report, again)
        third, third_report = nav.project(self.model(), first)
        self.assertEqual(g.serialize(first), g.serialize(third))
        self.assertEqual(report, third_report)

    def test_same_labels_keep_distinct_identity_contexts(self):
        self.element('other', '[Topic] Individual')
        self.element('other-child', '[Topic] Identity')
        self.edge()
        self.edge('other', 'other-child', rid='second')
        result, report = self.project()
        self.assertNotEqual(report['element_plan']['root']['context_folder'], report['element_plan']['other']['context_folder'])
        self.assertNotEqual(report['relationship_plan']['edge']['source_context_folder'], report['relationship_plan']['second']['source_context_folder'])
        self.assertEqual('PASS', nav.verify(self.model(), self.root, result, report)['unique_navigation_references'])

    def test_verifier_rejects_target_navigation_extra_references_and_semantic_mutation(self):
        self.edge()
        good, report = self.project()
        for mode in ('target', 'duplicate', 'semantic', 'folder-id'):
            result = copy.deepcopy(good)
            homes = nav.locations(result)
            if mode == 'target':
                folder = homes['edge'][0][0][-1]
                folder.find('a:label', g.N).text = '[Topic] Identity'
            elif mode == 'duplicate':
                homes['child'][0][1].getparent().append(copy.deepcopy(homes['child'][0][1]))
            elif mode == 'semantic':
                result.find('a:relationships/a:relationship', g.N).set('source', 'child')
            else:
                homes['child'][0][0][-1].set('identifier', 'wrong-projection-id')
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                nav.verify(self.model(), self.root, result, report)


class FrozenWorkspaceRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.outputs = run.build()
        cls.root = g.ET.fromstring(cls.outputs['candidate.xml'])
        cls.plan = json.loads(cls.outputs['workspace-projection.json'])
        cls.verification = json.loads(cls.outputs['verification.json'])

    def test_run001_naming_rebindings_identities_and_deferred_classification_are_preserved(self):
        for name in ('proposed-metadata.json', 'representation-rebindings.json'):
            self.assertEqual((run.RUNS / 'run-001' / name).read_bytes(), self.outputs[name])
        self.assertEqual((38, 32, 0), tuple(self.verification['population'][k] for k in ('representation_rebindings', 'new', 'deleted')))
        self.assertEqual(4, self.verification['naming']['unresolved'])
        self.assertEqual(0, self.verification['canonical_ids_allocated'])
        self.assertEqual(0, self.verification['semantic_changes'])

    def test_individual_tree_is_driven_by_composition_and_relations_by_actual_source(self):
        elements = nav.index(self.root, 'a:elements/a:element')
        individual, = [key for key, node in elements.items() if node.findtext('a:name', namespaces=g.N) == '[Topic] Individual']
        folder = nav.locations(self.root)[individual][0][0][-1]
        self.assertEqual('[Topic] Individual', folder.findtext('a:label', namespaces=g.N))
        names = {elements[item.get('identifierRef')].findtext('a:name', namespaces=g.N)
                 for item in folder.findall('a:item', g.N) if item.get('identifierRef')}
        self.assertEqual({'[Topic] ' + s for s in ('Individual', 'Authority', 'Contact', 'Demographics', 'Identity', 'Patient', 'Person', 'Relationship')}, names)
        homes = nav.locations(self.root)
        for rid, edge in nav.index(self.root, 'a:relationships/a:relationship').items():
            self.assertEqual(edge.get('source'), self.plan['relationship_plan'][rid]['source'])
            self.assertEqual(1, len(homes[rid]))

    def test_workforce_composition_and_equipment_aggregation_remain_distinct(self):
        elements = nav.index(self.root, 'a:elements/a:element')
        edges = nav.index(self.root, 'a:relationships/a:relationship')
        names = {node.findtext('a:name', namespaces=g.N): rid for rid, node in elements.items()}
        target = names['[Topic] CommunicationAddress']
        selected = {(elements[e.get('source')].findtext('a:name', namespaces=g.N), e.get(g.TYPE))
                    for e in edges.values() if e.get('target') == target}
        self.assertIn(('[Topic] Workforce', 'Composition'), selected)
        self.assertIn(('[Topic] Equipment', 'Aggregation'), selected)
        self.assertEqual([names['[Topic] Workforce'], target], self.plan['element_plan'][target]['composition_path'])

    def test_frozen_inputs_and_release_are_unchanged_and_sources_are_archived(self):
        manifest = json.loads(self.outputs['manifest.json'])
        self.assertEqual(manifest['frozen_files_before'], manifest['frozen_files_after'])
        self.assertEqual('1.0.10', manifest['release_authority']['version'])
        self.assertEqual(1394, len(self.root.findall('a:elements/a:element', g.N)))
        self.assertEqual(1137, len(self.root.findall('a:relationships/a:relationship', g.N)))
        self.assertTrue(self.outputs['candidate.xml'].startswith(b'<?xml'))
        for path, expected in manifest['source_sha256'].items():
            self.assertEqual(expected, naming.sha(naming.gzip.decompress(self.outputs['machinery/' + path + '.gz'])))

    def test_writer_refuses_existing_run_and_readonly_check_detects_changed_evidence(self):
        outputs = {'candidate.xml': b'plain XML', 'workspace-projection.json': b'{"summary":{}}'}
        with tempfile.TemporaryDirectory(dir='/tmp') as tmp, \
                mock.patch.object(run, 'RUNS', Path(tmp)), mock.patch.object(run, 'ROOT', Path(tmp)), \
                mock.patch.object(run, 'build', return_value=outputs):
            self.assertEqual(0, run.main([]))
            self.assertEqual(1, run.main([]))
            self.assertEqual(0, run.main(['--check']))
            candidate = Path(tmp) / 'run-002/candidate.xml'
            candidate.write_bytes(b'changed')
            self.assertEqual(1, run.main(['--check']))
            self.assertEqual(b'changed', candidate.read_bytes())


if __name__ == '__main__':
    unittest.main()
