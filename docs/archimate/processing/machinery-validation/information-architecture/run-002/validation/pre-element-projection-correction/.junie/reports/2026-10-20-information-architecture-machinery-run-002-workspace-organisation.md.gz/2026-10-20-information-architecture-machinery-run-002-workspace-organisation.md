<!-- Copyright (c) 2026 Mark Hunter. SPDX-License-Identifier: GPL-3.0-or-later -->

# Information Architecture machinery-validation run-002 — corrected containment and workspace organisation

## Result and review boundary

Run-002 now uses one framework containment interpretation for naming and workspace
projection. **Home is the default**; Composition applies only to the four native
type exceptions authorised by the Solution Architect. Preserved historical
assertions are filtered before parent selection. The old 61 direct / 109 propagated
multiple-parent diagnostic leaves **zero genuine current containment ambiguities**.

The regenerated principal [candidate.xml](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/candidate.xml)
is plain Open Exchange XML, ready for Solution Architect import into Archi. It is
**byte-identical to the pre-correction Run-002 candidate**, including its intended
IA element folders and relationship workspace organisation:

- SHA-256: `589759a0dbca2fb19f5a263a65309cc94fa10260797299d6c7e245061a828599`.
- 22,337,917 bytes; 1,394 elements, 1,137 relationships and 1,209 Views.
- Standing: **PROPOSED; NOT ACCEPTED; NOT A RAD RELEASE**.

This is completion/correction of Run-002. RAD remains **1.0.10**, predecessor
**1.0.9**. No Run-003, RAD-1.1.0, architecture reconciliation or Documentation
cleanup was undertaken. **The Archi round-trip was not started.**

## Authority and preserved history

The explicit Solution Architect instruction for this correction selects containment
by the **contained element's native type**. It narrows the earlier broad Composition
wording for this task without rewriting governance. The relevant authority is
[AX-04, AX-14 and AX-17](../../docs/markdown/governance/architectural-axioms.md),
the [canonical naming contract](../../docs/markdown/governance/canonical-identity-and-naming.md),
existing [Home governance](../../docs/markdown/governance/architecture-modelling-strategy.md#explicit-architectural-home)
and the [machinery-validation release exception](../../docs/markdown/governance/architecture-release-policy.md#machinery-validation-runs--2026-10-20).
The implementation reuses suitable machinery, preserves current/history and
architecture/projection distinctions, and detects ambiguity without choosing a parent.
No governance text was changed by this correction; broader wording reconciliation
remains outside scope.

The [supplementary diagnostic](2026-10-20-run-002-containment-framework-diagnostic.md)
is retained unchanged as the historical investigation. Its original findings are
not replaced by this corrected outcome. Complete pre-correction Run-002 output,
validation, relevant sources and this report's original version are hash-bound in
[the pre-correction archive](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/validation/pre-containment-correction/manifest.json).
All 130 archived original files are verified by the correction audit.

| Boundary | What existed or changed |
| --- | --- |
| Pre-existing framework | Capability/Composition navigation and source-based Relations placement predate IA work. Home recognition, accepted Business migration, Home naming/placement and currentness-aware containment View selection predate both runs. Home implementation/tests are present in `f40fad55`; earlier Capability/navigation history is detailed in the diagnostic. |
| Run-001 | Proposed IA naming from submitted Composition, reusing governed lexical qualification. Preserved navigation. Its evidence and candidate remain frozen. |
| Original Run-002 | Added IA folder projection, source-element relationship folders and a second Composition ancestry traversal. Its generic diagnostic omitted historical filtering. |
| This Run-002 correction | Extracts the established currentness selector, centralises Home/type-selected Composition and ancestry, refactors consumers, adds regressions, regenerates candidate/evidence. Preserves the original candidate bytes. |
| Test expectations | Test the Solution Architect's explicit rule and protected historical replay contracts. Tests do not supply architectural authority or approve the candidate. |

## Common containment interpretation

| Contained native ArchiMate type | Selected mechanism |
| --- | --- |
| Capability, including Harmonia Feature | Composition, parent → child |
| BusinessObject | Composition, parent → child |
| DataObject, including Harmonia Topic | Composition, parent → child |
| Artifact | Composition, parent → child |
| Every other applicable type | Home, contained element → architectural home |

Feature inherits Capability's rule; Topic inherits DataObject's rule. Subtypes,
labels, folder names and derived `harmoniaType` claims do not broaden the four
native exceptions. Home does not override Composition for these exception types;
Composition does not substitute for a missing Home on other types.

Home is the **Harmonia specialisation of native Association**. The existing
`home_relationships.authored_homes` recogniser is reused unchanged: resolve
`propertyDefinitionRef` to `Specialization` or `specialization`, require the explicit
value `Home`, native `Association` and `isDirected=true` or `1`. Relationship Name,
an ordinary Association, native Specialization or a folder cannot establish Home.
The existing Home direction is reversed only for the common parent/child graph;
the authored XML direction is never changed.

The processing sequence is:

```text
authored architecture relationships
  → shared current/historical population selection
  → contained-type selection of Home or Composition
  → common deterministic ancestry
  → naming and workspace/navigation projection
```

[`relationship_state.py`](../../docs/archimate/framework/tools/relationship_state.py)
extracts the established current-record/accepted-ingestion selector from containment
View selection. The Exchange adapter resolves actual Record State Property
definitions. Explicit preserved historical state is excluded before resolving
ancestry, while the native assertion remains in XML. Unclassified submitted
relationships remain conditional proposals, never implicitly accepted architecture.
A supplied governed record population remains exhaustive; accepted ingestion IDs
retain their established selection role.

[`containment.py`](../../docs/archimate/framework/tools/containment.py)
provides the shared selection and single iterative `Ancestry` engine. It detects
competing or duplicate current parents, cycles and missing endpoints; it does not
pick a winner. Required cross-scope ancestry stops the bounded projection.
[`resolved-containment.json`](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/resolved-containment.json)
records selected links, excluded states, wrong-mechanism relationships, conditional
proposals, ancestry and genuine findings. This specimen selects **212 Home** and
**632 Composition** links; it excludes **121 preserved historical assertions**.
The full relationship population has 513 explicit current-state records and 503
unclassified conditional assertions; these are not architectural approval counts.

## Framework reuse and removed duplication

The Run-002 runner resolves containment once and passes the same model to
`information_naming.propose`, `workspace_navigation.project` and its verifier.
The separate IA Composition walker and the verifier's independent Composition
traversal have been removed. Changing folders cannot change resolved containment.
The generic projector also supports Home-selected populations through this same
API; a regression exercises derived Home folders and ordinary Association rejection.

The bounded Capability reader in `generate_views.Model`, `publish_navigation`,
containment View selection and historical-reference metadata now use the common
model/ancestry. Their existing population, layer, accepted-ingestion and presentation
restrictions remain in force. No second current/historical selector was introduced.

Existing Home projection uses the shared Home selection and ancestry engine.
Older source-qualified naming replay in `home_context`, `synchronise_baseline`,
`governed_metadata` and `recover_v02` uses explicit recorded-context adapters to
that same graph walker. This preserves frozen accepted naming provenance, including
`naming_context`, `parent_key` and `owner_key` contracts; it does **not** turn those
records into native current containment. In the specimen, 173 of 179 Feature-classified
elements lack a native Composition parent. The correction does not invent those
relationships or rename/reorganise the protected Business population. Current
Exchange resolution uses the actual filtered architectural relationships.

Run-001's live naming consumer was refactored, but Run-002 requires its resulting
`proposed-metadata.json` to equal the **frozen Run-001 bytes**. Run-001's candidate,
source fingerprints and all evidence are unchanged. The 38 representation rebindings,
1,362 existing canonical identities, 32 absent new canonical IDs and four unresolved
legacy DataObject classifications are preserved. No identity was allocated.

The framework README now documents the common API and guarded correction mode.
Legacy JSON field names such as `composition_path` and the workspace projection
ID namespace remain stable for compatibility; they consume resolved containment,
not a separate Composition interpretation.

## Revised 61/109 diagnostic

The original diagnostic scanned all native Composition assertions regardless of
record state. All 61 direct cases had a current Composition parent plus a preserved
historical Composition assertion. Its other 48 findings were descendants affected
by that unfiltered traversal. All affected elements are native Capability; the
finding was not caused by applying Composition to an unauthorised native type.

The corrected resolver selects exactly one current direct relationship in every
one of the 61 cases and excludes its historical counterpart. All 109 affected
paths resolve deterministically. There are **zero current competing parents and
zero remaining model-wide containment findings** in this specimen. Historical
relationships are still present, with their original state, metadata and direction.

The reproducible [correction audit](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/validation/verify_containment_correction.py)
consumes the shared resolver evidence and archived old findings without adding an
ancestry implementation. Its [per-element disposition evidence](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/validation/containment-correction/diagnostic-transition.json)
records selected/excluded direct relationships and each resolved path.

## Element and relationship workspace result

The IA projection still covers every native BusinessObject, DataObject and Artifact,
including unresolved classifications. Collection anchors remain
`Business/BusinessObjectMap`, `Application/InformationMap` and
`Technology & Physical/DataMap`. The 86 elements comprise 12 BusinessObjects,
70 Topics and four unresolved DataObjects; there are no Artifacts. Native type,
Name, explicit specialisation and actual containment determine their proposed
names and navigation; collection anchors provide presentation only.

A parent with children has a same-named folder containing itself and direct leaf
references. Deeper parents have nested context folders; standalone elements retain
direct collection references. The Individual context contains Individual, Authority,
Contact, Demographics, Identity, Patient, Person and Relationship exactly once.
CommunicationAddress remains contained by Workforce; Equipment's Aggregation does
not create containment. Other element placement and complete Views are preserved.
No architectural containment is inferred from retained folders or View geometry.

| Measure | Corrected result, unchanged from original Run-002 |
| --- | ---: |
| Information elements projected | 86 |
| Root context folders / contained elements / standalone elements | 11 / 59 / 16 |
| Maximum IA containment depth, edges | 1 |
| Relationship-source contexts | 493 |
| Mirrored Relations path folders | 727 |
| Additional source folders | 482 |
| Total Relations folders, including root | 1,210 |
| Relationships referenced once | 1,137 |
| All workspace folders / navigation references | 4,391 / 3,740 |

**Relationship workspace organisation did not change in this correction.** Original
Run-002's layout mirrors the actual source element's resulting path, reuses parent
contexts and adds a source-element folder for leaves/standalone/non-IA sources.
Type and target do not choose relationship placement. Retained non-IA folder paths
are presentation scaffolding only. This remains the Run-002 extension described
in the supplementary diagnostic; it was not reverted to the older relationship
folder formula. All semantic relationships, including historical ones, retain
exactly one navigation reference.

Projection IDs retain their separate stable `workspace-` namespace, canonical or
frozen representation context and identity tie-breaks. Renaming, rebinding and
reparenting do not allocate architectural identity. Candidate byte equality and
exact equality of element/relationship placement plans establish layout preservation.

## Verification and reproduction

All commands run from the repository root with bounded execution:

| Check | Result |
| --- | --- |
| Focused containment/naming/workspace tests, 120-second bound | PASS — 56 tests, 41.386 seconds. |
| Focused containment/metadata/recovery tests after archival-adapter refactoring, 120-second bound | PASS — 54 tests, 41.926 seconds. |
| `timeout --signal=TERM --kill-after=5s 600s python3 -B -m unittest discover -s docs/archimate/framework/tests -v` | PASS — **295 tests**, 345.046 seconds, no failures/errors. Includes Home, all native exceptions/subtypes, state filtering, ambiguity, deterministic ancestry, folder projection, no reverse inference and frozen workspace preservation. |
| `timeout --signal=TERM --kill-after=5s 300s mvn test -pl paradeigma/paradeigma-test -am '-Dtest=*ArchitectureTest' -Dsurefire.failIfNoSpecifiedTests=false` | PASS — **90 tests**, no failures/errors/skips; Maven 18.610 seconds. |
| Guarded candidate regeneration, 120-second bound | PASS — corrected machinery regenerated the principal plain-XML candidate and hash-bound evidence. |
| Live `information_workspace_run.py --check`, 120-second bound | PASS — every generated byte and live source fingerprint reproduced without writes. |
| Isolated `validation/reproduce_candidate.py`, 120-second bound | PASS — candidate, naming, navigation and containment evidence byte-identical using archived sources only; 38 rebindings preserved. |
| `validation/verify_containment_correction.py` | PASS — all 61 direct / 109 affected cases resolved; no current ambiguities; candidate and both placement plans unchanged. |
| Schema, identifiers, references, protected-content reversal and unique navigation homes | PASS — includes protected semantic/Documentation/View preservation and offline XSD validation. |
| Frozen inputs, archived originals, release authority and whitespace | PASS — all 28 protected hashes and 130 archived originals verified; RAD 1.0.10 / 1.0.9; no whitespace errors. |
| Actual Archi import / complete-model round-trip / acceptance | Pending Solution Architect; not performed automatically. |

Logs and hash-bound verification are under
[correction validation](../../docs/archimate/processing/machinery-validation/information-architecture/run-002/validation/containment-correction/).
Development logs retain an obsolete helper reference found by the first focused
invocation and a separate misspelled test-class invocation. The helper test was
refactored to use the common resolver and the class invocation corrected. These
are distinguished from the final successful suites above.

The generator checks schema, IDs, references, unique navigation homes, shared
containment paths, exact regeneration and actual relationship sources. Restoring
only the original organisation subtree permits the established naming allowlist
verifier to reproduce the protected submission. Semantic content, authored
relationships, Documentation, Views, nodes, connections and geometry remain intact.

Live `--check` compares every generated output and the source-fingerprint manifest
without writing. Isolated replay restores hash-checked archived machinery and
frozen specimens into a temporary tree; it reproduces candidate XML, naming,
workspace and resolved-containment evidence byte for byte. The guarded
`--correct-run-002` mode verified the old output manifest/archive before replacing
only generated Run-002 evidence. Old validation results remain historical and are
linked separately from the correction results in `validation/manifest.json`.

## Frozen-input verification and stop point

All **28 protected files** retain their task-start SHA-256 values: published
RAD-1.0.10, the entire immutable architect submission directory, Run-001 evidence
and report, shared specimen manifest and root release authority. The no-edit Archi
control retains both its compressed and decompressed specimen hashes.

| Input | Unchanged SHA-256 |
| --- | --- |
| Published RAD-1.0.10 XML | `b1036f745e8ae3754951cd123b2b1a54a7eaa76c5fa83933abbd11ff2d4153bc` |
| Immutable submitted XML | `034dd70974245523ec11b503a9cf0535827d9ff6f161cafcabf002555dbf16ed` |
| No-edit control gzip | `1e2ecfb5585448c84eb009d22c9d1f7794d8e452f6d841865e08d675526aca8d` |
| No-edit control XML | `ac7fad3d30b230e894fa12e64e74e77939fc6574dd3336a8ddd7569f70c22b65` |
| Root release authority | `3ab2fd7b2b73733e2b4149fc4c682a8f0bf110c80b3543cf51200ebce3f47214` |

The corrected candidate and automated evidence are ready for **Solution Architect
inspection in Archi**. Manual import, rendered workspace usability, a later
complete-model export/comparison and architectural acceptance remain human gates.
No automated Archi round-trip or acceptance is claimed or initiated.
